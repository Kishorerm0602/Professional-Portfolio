/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type PageId =
  | 'home'
  | 'about'
  | 'projects'
  | 'experience'
  | 'skills'
  | 'research'
  | 'contact';

export interface EmailSubmission {
  senderName: string;
  senderEmail: string;
  category: string;
  priority: 'Routine' | 'High' | 'Clinical Collab';
  subject: string;
  message: string;
}
