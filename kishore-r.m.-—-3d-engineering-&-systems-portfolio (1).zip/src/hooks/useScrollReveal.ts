/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, RefObject } from 'react';

interface ScrollRevealOptions {
  rootRef?: RefObject<HTMLElement | null>;
  threshold?: number;
  rootMargin?: string;
  activeDependency?: any;
}

/**
 * Custom React hook that sets up an IntersectionObserver to trigger
 * subtle fade-in and slide-up entrance animations for elements as the user scrolls.
 */
export function useScrollReveal({
  rootRef,
  threshold = 0.08,
  rootMargin = '0px 0px -40px 0px',
  activeDependency,
}: ScrollRevealOptions = {}) {
  useEffect(() => {
    // If user prefers reduced motion, immediately reveal all elements without animation delay
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      const targets = document.querySelectorAll(
        '.reveal-on-scroll, .reveal-slide-left, .reveal-slide-right, .reveal-scale'
      );
      targets.forEach((el) => el.classList.add('is-revealed'));
      return;
    }

    const rootElement = rootRef?.current || null;

    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-revealed');
            // Unobserve once revealed to maintain 60fps performance
            obs.unobserve(entry.target);
          }
        });
      },
      {
        root: rootElement,
        threshold,
        rootMargin,
      }
    );

    // Give DOM a frame to render active page elements
    const timeout = setTimeout(() => {
      const scope = rootElement || document;
      const elements = scope.querySelectorAll(
        '.reveal-on-scroll:not(.is-revealed), .reveal-slide-left:not(.is-revealed), .reveal-slide-right:not(.is-revealed), .reveal-scale:not(.is-revealed)'
      );

      elements.forEach((el) => observer.observe(el));
    }, 50);

    return () => {
      clearTimeout(timeout);
      observer.disconnect();
    };
  }, [rootRef, threshold, rootMargin, activeDependency]);
}
