/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Sidebar } from './components/navigation/Sidebar';
import { TopBar } from './components/navigation/TopBar';
import { CommandPalette } from './components/navigation/CommandPalette';
import { SendEmailModal } from './components/contact/SendEmailModal';
import { HomeHero } from './components/hero/HomeHero';
import { AboutSection } from './components/about/AboutSection';
import { ProjectsSection } from './components/projects/ProjectsSection';
import { ExperienceSection } from './components/experience/ExperienceSection';
import { SkillsSection } from './components/skills/SkillsSection';
import { ResearchSection } from './components/research/ResearchSection';
import { ContactSection } from './components/contact/ContactSection';
import { useScrollReveal } from './hooks/useScrollReveal';

export default function App() {
  const [activePage, setActivePage] = useState<string>('home');
  const [isDark, setIsDark] = useState<boolean>(false);
  const [isCmdkOpen, setIsCmdkOpen] = useState<boolean>(false);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState<boolean>(false);
  const [isMobileNavOpen, setIsMobileNavOpen] = useState<boolean>(false);
  const [scrollProgress, setScrollProgress] = useState<number>(0);
  const [isBootDone, setIsBootDone] = useState<boolean>(false);

  const contentRef = useRef<HTMLDivElement>(null);
  const glowRef = useRef<HTMLDivElement>(null);

  // IntersectionObserver hook for subtle scroll entrance animations
  useScrollReveal({
    rootRef: contentRef,
    threshold: 0.08,
    rootMargin: '0px 0px -30px 0px',
    activeDependency: activePage,
  });

  // Initialize theme from system preference or previous storage
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
      setIsDark(true);
      document.documentElement.classList.add('dark');
    } else {
      setIsDark(false);
      document.documentElement.classList.remove('dark');
    }

    // Dismiss boot loader after brief initial sequence
    const bootTimer = setTimeout(() => {
      setIsBootDone(true);
    }, 700);

    return () => clearTimeout(bootTimer);
  }, []);

  const toggleTheme = () => {
    setIsDark((prev) => {
      const next = !prev;
      if (next) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('theme', 'light');
      }
      return next;
    });
  };

  // Track scroll progress rail
  const handleScroll = () => {
    const el = contentRef.current;
    if (!el) return;
    const max = el.scrollHeight - el.clientHeight;
    const pct = max > 0 ? (el.scrollTop / max) * 100 : 0;
    setScrollProgress(pct);
  };

  // Cursor glow on fine pointer devices
  useEffect(() => {
    const glow = glowRef.current;
    if (!glow || !window.matchMedia('(pointer: fine)').matches) return;

    const handleMouseMove = (e: MouseEvent) => {
      glow.style.setProperty('--cx', `${e.clientX}px`);
      glow.style.setProperty('--cy', `${e.clientY}px`);
      glow.classList.add('live');
    };

    const handleMouseLeave = () => {
      glow.classList.remove('live');
    };

    window.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  // Global keyboard shortcuts (⌘K for command palette, 1-7 for sections)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // ⌘K or Ctrl+K
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCmdkOpen((prev) => !prev);
        return;
      }

      // Do not trigger numbers if focused in an input/textarea
      const activeTag = document.activeElement?.tagName.toLowerCase();
      if (activeTag === 'input' || activeTag === 'textarea' || activeTag === 'select') {
        return;
      }

      const keyMap: Record<string, string> = {
        '1': 'home',
        '2': 'about',
        '3': 'projects',
        '4': 'experience',
        '5': 'skills',
        '6': 'research',
        '7': 'contact',
      };

      if (keyMap[e.key]) {
        setActivePage(keyMap[e.key]);
        contentRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const navigateToPage = (page: string) => {
    setActivePage(page);
    contentRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--ink)] flex flex-col font-sans selection:bg-[var(--accent)] selection:text-white">
      {/* Boot Loader */}
      {!isBootDone && (
        <div className="fixed inset-0 z-[9999] bg-[var(--bg)] flex items-center justify-center transition-opacity duration-500">
          <div className="flex flex-col items-center gap-4">
            <svg className="w-56 h-12" viewBox="0 0 220 48">
              <path
                className="vital-path"
                d="M0,24 L40,24 L48,8 L58,40 L66,24 L78,24 L86,16 L94,32 L102,24 L220,24"
              />
            </svg>
            <div className="font-mono-code text-[10px] tracking-widest uppercase text-[var(--ink3)]">
              initializing profile…
            </div>
          </div>
        </div>
      )}

      {/* Scroll Progress Rail */}
      <div
        className="scroll-rail"
        style={{ width: `${scrollProgress}%` }}
        aria-hidden="true"
      />

      {/* Desktop Cursor Glow */}
      <div ref={glowRef} className="cursor-glow" aria-hidden="true" />

      {/* Command Palette Modal */}
      <CommandPalette
        isOpen={isCmdkOpen}
        onClose={() => setIsCmdkOpen(false)}
        onNavigate={navigateToPage}
        onOpenEmailModal={() => setIsEmailModalOpen(true)}
      />

      {/* Send Email Modal */}
      <SendEmailModal
        isOpen={isEmailModalOpen}
        onClose={() => setIsEmailModalOpen(false)}
      />

      {/* Master Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-[264px_1fr] min-h-screen">
        {/* Left Sidebar */}
        <Sidebar
          activePage={activePage}
          onNavigate={navigateToPage}
          isDark={isDark}
          onToggleTheme={toggleTheme}
          onOpenCmdk={() => setIsCmdkOpen(true)}
          onOpenEmailModal={() => setIsEmailModalOpen(true)}
          isOpenMobile={isMobileNavOpen}
          onCloseMobile={() => setIsMobileNavOpen(false)}
        />

        {/* Main Content Area */}
        <div className="flex flex-col min-w-0 lg:pl-[264px]">
          {/* Top Bar Navigation */}
          <TopBar
            activePage={activePage}
            onOpenMobileNav={() => setIsMobileNavOpen(true)}
            onOpenEmailModal={() => setIsEmailModalOpen(true)}
            onNavigateToContact={() => {
              navigateToPage('contact');
              setIsEmailModalOpen(true);
            }}
          />

          {/* Page Display Scroll Container */}
          <main
            ref={contentRef}
            onScroll={handleScroll}
            className="flex-1 overflow-y-auto"
          >
            {activePage === 'home' && (
              <HomeHero
                onNavigate={navigateToPage}
                onOpenEmailModal={() => setIsEmailModalOpen(true)}
              />
            )}

            {activePage === 'about' && <AboutSection />}

            {activePage === 'projects' && <ProjectsSection />}

            {activePage === 'experience' && <ExperienceSection />}

            {activePage === 'skills' && <SkillsSection />}

            {activePage === 'research' && <ResearchSection />}

            {activePage === 'contact' && (
              <ContactSection
                onOpenEmailModal={() => setIsEmailModalOpen(true)}
              />
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
