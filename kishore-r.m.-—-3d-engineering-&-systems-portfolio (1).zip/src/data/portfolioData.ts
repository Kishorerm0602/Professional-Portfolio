/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ProjectData {
  id: string;
  title: string;
  badge: 'Contribution' | 'Full Stack' | 'Frontend' | 'Private';
  tags: string[];
  description: string;
  image: string;
  githubUrl: string;
  wide?: boolean;
  biomedicalRelevance?: string;
}

export interface ExperienceItem {
  id: string;
  date: string;
  role: string;
  organization: string;
  description: string;
  tags: string[];
  current?: boolean;
}

export interface CertificationItem {
  id: string;
  issuer: string;
  name: string;
  date: string;
  image: string;
  verified: boolean;
}

export interface ResearchItem {
  id: string;
  status: 'draft' | 'progress' | 'published';
  statusLabel: string;
  title: string;
  venue: string;
  abstract: string;
  tags: string[];
  meta: {
    status: string;
    targetVenueOrBasis: string;
    targetVenueLabel: string;
    year: string;
  };
}

export interface SkillCategory {
  title: string;
  skills: { name: string; percentage: number; warm?: boolean }[];
}

export const PERSONAL_INFO = {
  name: 'Kishore R M',
  title: "BME '29 · Healthcare AI",
  roleHeadline: 'Biomedical Engineer & Healthcare AI Developer',
  institution: 'J.N.N Institute of Engineering, Chennai',
  batch: '2025–2029',
  degree: 'B.E. Biomedical Engineering',
  location: 'Chennai, Tamil Nadu, India',
  neighborhood: 'Saidapet',
  email: 'rmkishore498@gmail.com',
  academicEmail: 'rmkishore46@jnn.edu.in',
  githubUsername: 'Kishorerm0602',
  githubUrl: 'https://github.com/Kishorerm0602',
  linkedinUrl: 'https://www.linkedin.com/in/kishore-rm-a93bb0386',
  orcidId: '0009-0007-3212-1068',
  orcidUrl: 'https://orcid.org/0009-0007-3212-1068',
  availability: 'Open to opportunities',
  bio: `Second-year Biomedical Engineering student at J.N.N Institute of Engineering, Chennai — building intelligent healthcare systems at the intersection of clinical science, machine learning, and modern software development.`,
  detailedBio: [
    `Hello! I'm Kishore, a Biomedical Engineering student with a strong passion for software development and emerging technologies. I'm currently focusing on Machine Learning, Python programming, and IoT, exploring how technology can solve real-world problems, particularly in healthcare and biomedical applications.`,
    `I enjoy learning new technologies, working on innovative projects, and continuously improving my technical skills through hands-on experience, certifications, research, and open-source contributions. My goal is to build intelligent solutions that bridge the gap between healthcare and technology while developing a strong foundation in modern software engineering.`,
    `Apart from academics, I actively participate in technical communities, coding challenges, and open-source programs such as GirlScript Summer of Code (GSSoC 2026). I am passionate about innovation, problem-solving, and lifelong learning, always seeking opportunities to grow both personally and professionally.`,
  ],
  stats: [
    { value: '5+', label: 'Projects Built' },
    { value: '7+', label: 'Open Source Contributions' },
    { value: '1+', label: 'NPTEL Certification' },
    { value: '1+', label: 'Research Papers' },
  ],
  targetCompanies: ['GE HealthCare', 'Siemens Healthineers', 'Philips', 'MedTech Startups'],
  interests: [
    {
      title: 'Biomedical Focus',
      description: 'Medical imaging, biomaterials, clinical instrumentation, HL7/FHIR systems, and patient data pipelines.',
    },
    {
      title: 'Software Focus',
      description: 'Full-stack development with Machine Learning, Python, FastAPI, React, and IoT. Creating healthcare-focused applications.',
    },
    {
      title: 'Career Target',
      description: 'MedTech placements at GE HealthCare, Siemens Healthineers, Philips, or Health-AI research labs.',
    },
    {
      title: 'Ongoing Challenge',
      description: 'Contributing to open-source in GSSoC 2026, collaborating with developers, and strengthening software engineering craft.',
    },
  ],
  languages: [
    { name: 'Tamil (Native)', percentage: 100 },
    { name: 'English', percentage: 90 },
    { name: 'German (Learning)', percentage: 30 },
  ],
  education: [
    {
      institution: 'Chennai Boys Higher Secondary School, Saidapet',
      degree: 'Higher Secondary Education',
      period: '2024 — 2025 · Completed',
    },
    {
      institution: 'J.N.N Institute of Engineering, Chennai',
      degree: 'B.E. Biomedical Engineering',
      period: '2025 — 2029 · Current',
    },
  ],
};

export const PROJECTS: ProjectData[] = [
  {
    id: 'the-lighthouse',
    title: 'The Lighthouse',
    badge: 'Contribution',
    tags: ['HTML', 'CSS', 'JavaScript', 'Node.js'],
    description:
      'The Lighthouse is a modern web platform designed to guide users toward valuable resources, opportunities, and information through a clean and intuitive digital experience.',
    image: 'https://thelighthouse.ae/cdn/shop/files/The-Lighthouse-Restaurant-Dubai-Hills.jpg?v=1733967304&width=3000',
    githubUrl: 'https://github.com/Kishorerm0602/The-Lighthouse',
    biomedicalRelevance: 'Information architecture and intuitive navigation for accessibility.',
  },
  {
    id: 'travel-planner',
    title: 'Travel Planner',
    badge: 'Contribution',
    tags: ['HTML', 'CSS', 'JavaScript', 'Node.js'],
    description:
      'Travel Plans is a modern travel planning web application that helps users organize trips, explore destinations, and manage itineraries through an intuitive and responsive interface.',
    image: 'https://static.vecteezy.com/system/resources/previews/010/846/818/original/mountain-tree-and-airplane-logo-design-travel-logo-design-road-trip-logo-vector.jpg',
    githubUrl: 'https://github.com/Kishorerm0602/Travel-Plans-',
    biomedicalRelevance: 'Dynamic schedule algorithms adaptable to patient mobile care logistics.',
  },
  {
    id: 'event-management',
    title: 'Event Management System',
    badge: 'Contribution',
    tags: ['Full Stack', 'React', 'FastAPI'],
    description:
      'A full-stack event management system with user authentication, event creation, participant tracking, and automated registration features.',
    image: 'https://strapi-file-uploads.parkplus.io/DALL_E_2024_11_29_12_26_07_An_informative_and_visually_engaging_image_representing_an_event_management_system_showcasing_a_professional_setting_with_organizers_planning_an_even_9bbb491c9d.webp',
    githubUrl: 'https://github.com/Kishorerm0602/Event-management-system-main',
    biomedicalRelevance: 'Role-based access patterns useful for clinical hospital rotations.',
  },
  {
    id: 'wanderlust',
    title: 'Wanderlust',
    badge: 'Frontend',
    tags: ['HTML', 'CSS', 'JavaScript'],
    description:
      'Wanderlust is a travel and cultural exploration initiative that inspires learning, adventure, and meaningful connections through interactive web interfaces.',
    image: 'https://img.freepik.com/premium-vector/wanderlust_763182-143.jpg',
    githubUrl: 'https://github.com/Kishorerm0602/ticket_booking',
    biomedicalRelevance: 'Interactive booking patterns comparable to patient appointment dispatchers.',
  },
  {
    id: '100-days-web',
    title: '100 Days · 100 Web Projects',
    badge: 'Contribution',
    tags: ['Frontend', 'JavaScript', 'UI Design'],
    description:
      'A daily challenge building advanced, animated UI components — from glassmorphic panels to interactive data visualizers — to sharpen frontend craft one project at a time.',
    image: 'https://wallpapercave.com/wp/wp2234696.jpg',
    githubUrl: 'https://github.com/Kishorerm0602/100_days_100_web_project',
    biomedicalRelevance: 'Rapid user-interface prototyping for diagnostic instrumentation readouts.',
  },
  {
    id: 'moovit',
    title: 'Moovit',
    badge: 'Contribution',
    tags: ['Frontend', 'JavaScript', 'Assistive Tech'],
    description:
      'MooVit is a smart real-time safety assistant that helps visually impaired users by detecting people, vehicles, signals, and obstacles, and gives voice alerts to guide them safely in road environments.',
    image: 'https://as2.ftcdn.net/v2/jpg/04/68/05/77/1000_F_468057761_5Tygxjd5BexV7T0sPNuqS1LwgHFXobUm.jpg',
    githubUrl: 'https://github.com/Kishorerm0602/MooVit',
    biomedicalRelevance: 'Assistive biomedical sensory augmentation for the visually impaired.',
  },
  {
    id: 'aura',
    title: 'Aura',
    badge: 'Private',
    tags: ['Python', 'AI Chatbot', 'Speech Recognition'],
    description:
      'Aura is an AI-powered voice assistant bot that enables hands-free interaction through speech recognition, natural language processing, and task automation.',
    image: 'https://tse4.mm.bing.net/th/id/OIP.eGsMlc6M-6q70CLpsL5z6AHaDa?rs=1&pid=ImgDetMain&o=7&rm=3',
    githubUrl: 'https://github.com/Kishorerm0602/Aura',
    wide: true,
    biomedicalRelevance: 'Hands-free sterile voice control for clinical environments & surgical suites.',
  },
];

export const EXPERIENCES: ExperienceItem[] = [
  {
    id: 'jnn-bme',
    date: '2025 — Present',
    role: 'B.E. Biomedical Engineering',
    organization: 'J.N.N Institute of Engineering, Chennai · Batch 2025–2029',
    description:
      'Core coursework spanning biomedical instrumentation, medical image analysis, biomaterials, clinical data systems, and signals processing. Running a parallel track in software engineering, AI, and open-source development.',
    tags: ['Medical Imaging', 'Biomaterials', 'Instrumentation', 'Clinical Systems'],
    current: true,
  },
  {
    id: 'gssoc-2026',
    date: '2026 · Active',
    role: 'Open Source Contributor',
    organization: 'GSSoC 2026 — GirlScript Summer of Code',
    description:
      'Active contributor in GSSoC 2026, participating in the full open-source workflow: issue claiming, branch management, pull requests, and code review. Shipped an advanced Transport Co. landing page and multiple web components.',
    tags: ['React', 'HTML/CSS', 'GitHub PRs', 'Open Source'],
  },
  {
    id: 'csc-hdca',
    date: '2025 · Completed',
    role: 'HDCA Course',
    organization: 'CSC Computer Software College, Chennai',
    description:
      'Completed software training at CSC Computer Software College, building foundational skills in programming, computer applications, and digital technology solutions.',
    tags: ['HTML', 'CSS', 'JavaScript', 'Python', 'Software Training'],
  },
  {
    id: 'mmm-hospital',
    date: '2026 · Completed',
    role: 'Internship and Training',
    organization: 'MMM Hospital, Chennai',
    description:
      'Hospital Training – MMM Hospital: Gained exposure to medical equipment, patient monitoring systems, and the practical role of biomedical engineers in a clinical healthcare environment.',
    tags: ['Medical Devices', 'Patient Monitoring', 'Clinical Environment', 'Biomedical Engineering'],
  },
  {
    id: 'annai-healthcare',
    date: '2026 · Completed',
    role: 'Clinical Training',
    organization: 'Annai Healthcare, Chennai',
    description:
      'Observed clinical workflows and medical equipment operations, gaining insight into healthcare technology and patient care practices.',
    tags: ['Clinical Workflows', 'Clinical Exposure', 'Healthcare Technology', 'Patient Care'],
  },
];

export const CERTIFICATIONS: CertificationItem[] = [
  {
    id: 'nptel-iit',
    issuer: 'IIT Kharagpur · NPTEL',
    name: 'Medical Image Analysis Course',
    date: '2025 · Verified',
    image: 'https://snckollam.ac.in/kezoofti/2020/08/nptel.jpg',
    verified: true,
  },
  {
    id: 'csc-diploma',
    issuer: 'CSC Chennai · Computer Software College',
    name: 'Honourable Diploma in Computer Application',
    date: '2025 · Certified & Verified',
    image: 'https://cdn.zyrosite.com/cdn-cgi/image/format=auto,w=1200,h=630,fit=crop,f=jpeg/cdn-ecommerce/store_01HECH53R7P2WYA8PECKJSTYCT/assets/1699086097554-11.png',
    verified: true,
  },
  {
    id: 'mmm-cert',
    issuer: 'MMM Hospital, Chennai',
    name: 'Internship and Training',
    date: '2026 · Completed & Verified',
    image: 'https://th.bing.com/th/id/R.404ce75ce25857972b43bd632dacb563?rik=62z7U1LxnXJQUg&riu=http%3a%2f%2fmmmcollegeofnursing.org%2fassets%2fimages%2fservices%2fmmm1.jpg&ehk=dFT0f3hOGDiga9PGyXoylcv6%2bhmq0CHKfV5AReEPF9g%3d&risl=&pid=ImgRaw&r=0',
    verified: true,
  },
  {
    id: 'gssoc-cert',
    issuer: 'GirlScript Foundation',
    name: 'GSSoC 2026 Contributor',
    date: '2026 · Active',
    image: 'https://www.nexb.com/wp-content/uploads/2022/03/gsoc-sun-logo-new.png',
    verified: true,
  },
  {
    id: 'cisco-python',
    issuer: 'Cisco Networking Academy',
    name: 'Python Essentials 1',
    date: '2026 · Completed & Certified',
    image: 'https://tse2.mm.bing.net/th/id/OIP.C9tgcruNTFROeAaFN5FwmAHaHa?rs=1&pid=ImgDetMain&o=7&rm=3',
    verified: true,
  },
];

export const SKILL_CATEGORIES: SkillCategory[] = [
  {
    title: 'Biomedical Domain',
    skills: [
      { name: 'Medical Imaging', percentage: 42 },
      { name: 'Biomaterials', percentage: 68 },
      { name: 'Instrumentation', percentage: 65 },
      { name: 'Circuit Board Design', percentage: 80 },
    ],
  },
  {
    title: 'Software Development',
    skills: [
      { name: 'HTML/CSS', percentage: 75, warm: true },
      { name: 'JavaScript', percentage: 80, warm: true },
      { name: 'MERN Full Stack', percentage: 35, warm: true },
      { name: 'Python', percentage: 70, warm: true },
    ],
  },
  {
    title: 'Additional Skills',
    skills: [
      { name: 'Project Management', percentage: 82 },
      { name: 'UI/UX Design', percentage: 76 },
      { name: 'C / C++', percentage: 70 },
      { name: 'DSA', percentage: 74 },
      { name: 'Prompt Engineering', percentage: 80 },
    ],
  },
];

export const TOOLS_LIST = [
  'VS Code',
  'ChatGPT',
  'Git / GitHub',
  'Figma',
  'Jira',
  'Linux',
  'APM Tools',
  'Claude',
  'Bolt.new',
  'Lovable',
  'CodeBlocks',
  'Replit',
  'AntiGravity',
  'Grok',
];

export const DOMAIN_KNOWLEDGE_LIST = [
  'Medical Signal Processing',
  'Image Segmentation',
  'Biomaterials & Implants',
  'Clinical Workflows',
  'Manufacturing',
  'Marketing',
  'Data Analysis',
  'Software Engineering',
  'AI & Machine Learning',
];

export const RESEARCH_ITEMS: ResearchItem[] = [
  {
    id: 'rag-clinical',
    status: 'draft',
    statusLabel: 'Problem Statement',
    title: 'Retrieval-Augmented Generation for Clinical Knowledge Access',
    venue: 'IEEE-style problem statement · Derived from MediBot X',
    abstract:
      'Explores RAG architectures combining vector retrieval with LLM reasoning for grounded, citation-aware clinical information access with patient privacy guards.',
    tags: ['RAG', 'LLM', 'Biomedical Informatics'],
    meta: {
      status: 'Drafting',
      targetVenueOrBasis: 'Zenodo / ResearchGate',
      targetVenueLabel: 'Target Venue',
      year: '2026',
    },
  },
  {
    id: 'emergency-response',
    status: 'draft',
    statusLabel: 'Problem Statement',
    title: 'Location-Aware Emergency Response Systems',
    venue: 'IEEE-style problem statement · Derived from RoadSoS',
    abstract:
      'Formalizes design constraints for emergency assistance systems with offline-first architectures, edge triage, and low-latency geospatial dispatching.',
    tags: ['Emergency Systems', 'Offline-First', 'Geolocation'],
    meta: {
      status: 'Formalized',
      targetVenueOrBasis: 'RoadSoS Project',
      targetVenueLabel: 'Based On',
      year: '2026',
    },
  },
  {
    id: 'conversational-ai',
    status: 'draft',
    statusLabel: 'Problem Statement',
    title: 'Conversational AI for Patient Education',
    venue: 'IEEE-style problem statement · Derived from CareGPT',
    abstract:
      'Examines safety boundaries for LLM-based patient-facing healthcare chatbots with clinical validation criteria and medical terminology grounding.',
    tags: ['Conversational AI', 'Clinical Safety', 'Patient Education'],
    meta: {
      status: 'Formalized',
      targetVenueOrBasis: 'CareGPT Project',
      targetVenueLabel: 'Based On',
      year: '2026',
    },
  },
  {
    id: 'civic-ai-literacy',
    status: 'draft',
    statusLabel: 'Problem Statement',
    title: 'Civic AI Literacy & Election Education',
    venue: 'IEEE-style problem statement · Derived from VoteWise',
    abstract:
      'Investigates conversational interfaces for neutral, verifiable civic education at scale, preventing misinformation propagation through factual retrieval.',
    tags: ['Civic Tech', 'AI Literacy', 'Trust & Safety'],
    meta: {
      status: 'Formalized',
      targetVenueOrBasis: 'VoteWise Project',
      targetVenueLabel: 'Based On',
      year: '2026',
    },
  },
];
