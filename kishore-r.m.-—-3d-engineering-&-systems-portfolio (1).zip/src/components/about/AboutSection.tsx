/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { PERSONAL_INFO } from '../../data/portfolioData';

export const AboutSection: React.FC = () => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_380px] min-h-[calc(100vh-3.5rem)] bg-[var(--rule)] gap-[1px]">
      {/* Main Column */}
      <div className="p-8 sm:p-12 lg:p-14 bg-[var(--surface)]">
        <div className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--accent)] mb-2 flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[var(--vital)]" />
          <span>// about</span>
        </div>

        <h2 className="font-syne font-bold text-3xl sm:text-4xl lg:text-5xl text-[var(--ink)] tracking-tight mb-2">
          Engineering the Future of Medicine
        </h2>
        <p className="font-epilogue italic text-sm text-[var(--ink3)] mb-10">
          Biomedical Engineer · Software Developer · Healthcare AI Builder
        </p>

        {/* Image Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-[1.3fr_1fr] gap-3 mb-10">
          <div className="relative aspect-[4/3] rounded overflow-hidden border border-[var(--rule)] group reveal-on-scroll delay-1">
            <img
              src="https://images.unsplash.com/photo-1530497610245-94d3c16cda28?w=700&q=80"
              alt="Biomedical Research Lab"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 saturate-[0.85] group-hover:saturate-100"
            />
            <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/70 to-transparent font-mono-code text-[10px] uppercase tracking-wider text-white">
              Research & Diagnostic Imaging
            </div>
          </div>

          <div className="relative aspect-[4/3] rounded overflow-hidden border border-[var(--rule)] group reveal-on-scroll delay-2">
            <img
              src="https://images.unsplash.com/photo-1576671081837-49000212a370?w=600&q=80"
              alt="Medical Technology Instrumentation"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 saturate-[0.85] group-hover:saturate-100"
            />
            <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/70 to-transparent font-mono-code text-[10px] uppercase tracking-wider text-white">
              Medical Technology & Biosensors
            </div>
          </div>
        </div>

        {/* Biography Paragraphs */}
        <div className="space-y-4 text-[15px] text-[var(--ink2)] leading-relaxed font-epilogue mb-10">
          {PERSONAL_INFO.detailedBio.map((paragraph, idx) => (
            <p key={idx} className={`reveal-on-scroll delay-${idx + 1}`}>
              {paragraph}
            </p>
          ))}
        </div>

        {/* Interest Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {PERSONAL_INFO.interests.map((card, idx) => (
            <div
              key={idx}
              className={`p-5 bg-[var(--bg)] border border-[var(--rule)] border-l-2 border-l-[var(--rule)] hover:border-l-[var(--vital)] hover:border-[var(--accent)] hover:bg-[var(--accent-pale)] rounded transition-all reveal-on-scroll delay-${idx + 1}`}
            >
              <div className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--accent)] mb-2 font-medium">
                {card.title}
              </div>
              <p className="text-xs text-[var(--ink2)] leading-relaxed font-epilogue">
                {card.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Right Column / Sidebar Details */}
      <div className="p-8 sm:p-10 bg-[var(--bg2)] space-y-10">
        {/* Education Section */}
        <div>
          <div className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--ink3)] pb-2.5 border-b border-[var(--rule)] mb-4 font-semibold">
            Education
          </div>
          <div className="space-y-4">
            {PERSONAL_INFO.education.map((edu, idx) => (
              <div
                key={idx}
                className="pb-4 border-b border-[var(--rule)] last:border-b-0 group"
              >
                <div className="font-syne font-semibold text-[13.5px] text-[var(--ink)] mb-0.5 group-hover:text-[var(--accent)] transition-colors">
                  {edu.degree}
                </div>
                <div className="text-xs text-[var(--ink2)] mb-1 font-epilogue">
                  {edu.institution}
                </div>
                <div className="font-mono-code text-[10px] text-[var(--ink3)]">
                  {edu.period}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Languages Section */}
        <div>
          <div className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--ink3)] pb-2.5 border-b border-[var(--rule)] mb-4 font-semibold">
            Languages
          </div>
          <div className="space-y-3.5">
            {PERSONAL_INFO.languages.map((lang, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-[var(--ink2)]">{lang.name}</span>
                  <span className="font-mono-code text-[11px] text-[var(--accent)] font-medium">
                    {lang.percentage}%
                  </span>
                </div>
                <div className="h-1 bg-[var(--rule)] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[var(--accent)] rounded-full transition-all duration-1000"
                    style={{ width: `${lang.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Based In Card */}
        <div>
          <div className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--ink3)] pb-2.5 border-b border-[var(--rule)] mb-4 font-semibold">
            Based In
          </div>
          <div className="rounded border border-[var(--rule)] overflow-hidden bg-[var(--surface)]">
            <img
              src="https://as1.ftcdn.net/v2/jpg/05/25/80/12/1000_F_525801231_NyTyxwDuMAkF2lb1n35Q4FaJWO7Mu1Y3.jpg"
              alt="Chennai, Tamil Nadu"
              className="w-full h-28 object-cover saturate-[0.85]"
            />
            <div className="p-3 text-xs text-[var(--ink2)]">
              <strong className="block font-syne font-bold text-sm text-[var(--ink)] mb-0.5">
                Chennai, Tamil Nadu
              </strong>
              Saidapet · Open to remote & relocation
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
