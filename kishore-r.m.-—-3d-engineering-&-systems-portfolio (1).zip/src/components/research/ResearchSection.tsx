/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { RESEARCH_ITEMS, PERSONAL_INFO } from '../../data/portfolioData';
import { BookOpen, ExternalLink, Sparkles } from 'lucide-react';

export const ResearchSection: React.FC = () => {
  return (
    <div className="p-8 sm:p-12 lg:p-16 max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--accent)] mb-2 flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[var(--vital)]" />
          <span>// research</span>
        </div>
        <h2 className="font-syne font-bold text-3xl sm:text-4xl text-[var(--ink)] tracking-tight mb-1">
          Research & Publications
        </h2>
        <p className="font-epilogue italic text-sm text-[var(--ink3)]">
          Formalizing engineering projects into research-grade clinical problem statements
        </p>
      </div>

      {/* Research Stats Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-[1px] bg-[var(--rule)] border border-[var(--rule)] rounded-lg overflow-hidden mb-10">
        <div className="p-6 bg-[var(--surface)] hover:bg-[var(--bg)] transition-colors reveal-on-scroll delay-1">
          <div className="font-syne font-bold text-3xl text-[var(--ink)] mb-1">4</div>
          <div className="font-mono-code text-[10px] uppercase tracking-wider text-[var(--ink3)]">
            Problem Statements
          </div>
        </div>
        <div className="p-6 bg-[var(--surface)] hover:bg-[var(--bg)] transition-colors reveal-on-scroll delay-2">
          <div className="font-syne font-bold text-3xl text-[var(--ink)] mb-1">1</div>
          <div className="font-mono-code text-[10px] uppercase tracking-wider text-[var(--ink3)]">
            NPTEL Certification
          </div>
        </div>
        <div className="p-6 bg-[var(--surface)] hover:bg-[var(--bg)] transition-colors reveal-on-scroll delay-3">
          <div className="font-syne font-bold text-3xl text-[var(--accent)] mb-1">
            0009
          </div>
          <div className="font-mono-code text-[10px] uppercase tracking-wider text-[var(--ink3)]">
            ORCID Registered
          </div>
        </div>
      </div>

      {/* Problem Statements List */}
      <div className="space-y-4">
        {RESEARCH_ITEMS.map((item, rIdx) => (
          <div
            key={item.id}
            className={`p-7 bg-[var(--surface)] border border-[var(--rule)] rounded-lg hover:border-[var(--accent)] transition-all grid grid-cols-1 lg:grid-cols-[1fr_220px] gap-6 group reveal-on-scroll delay-${(rIdx % 4) + 1}`}
          >
            {/* Left Content */}
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[9.5px] font-mono-code uppercase tracking-wider mb-3 bg-[var(--bg2)] text-[var(--ink3)]">
                <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent)] animate-pulse-mini" />
                <span>{item.statusLabel}</span>
              </div>

              <h3 className="font-syne font-bold text-xl text-[var(--ink)] tracking-tight mb-1.5 group-hover:text-[var(--accent)] transition-colors">
                {item.title}
              </h3>

              <div className="text-xs text-[var(--ink3)] italic mb-3 font-epilogue">
                {item.venue}
              </div>

              <p className="text-xs sm:text-[13.5px] text-[var(--ink2)] leading-relaxed font-epilogue mb-4">
                {item.abstract}
              </p>

              <div className="flex flex-wrap gap-1.5">
                {item.tags.map((tag, tIdx) => (
                  <span
                    key={tIdx}
                    className="px-2.5 py-0.5 bg-[var(--bg2)] border border-[var(--rule)] rounded text-[9.5px] font-mono-code text-[var(--ink3)] group-hover:border-[var(--accent)]/30 transition-colors"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Right Meta Column */}
            <div className="lg:border-l border-[var(--rule)] lg:pl-6 pt-4 lg:pt-0 flex flex-col justify-between text-xs space-y-3">
              <div>
                <div className="font-mono-code text-[9.5px] uppercase tracking-wider text-[var(--ink4)] mb-0.5">
                  Status
                </div>
                <div className="font-medium text-[var(--ink)] font-mono-code">
                  {item.meta.status}
                </div>
              </div>

              <div>
                <div className="font-mono-code text-[9.5px] uppercase tracking-wider text-[var(--ink4)] mb-0.5">
                  {item.meta.targetVenueLabel}
                </div>
                <div className="font-medium text-[var(--accent)] font-mono-code">
                  {item.meta.targetVenueOrBasis}
                </div>
              </div>

              <div>
                <div className="font-mono-code text-[9.5px] uppercase tracking-wider text-[var(--ink4)] mb-0.5">
                  Year
                </div>
                <div className="font-medium text-[var(--ink)] font-mono-code">
                  {item.meta.year}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* ORCID Registry Card */}
      <div className="mt-8 p-5 bg-[var(--surface)] border border-[var(--rule)] rounded-lg flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#A6CE39] text-white flex items-center justify-center font-bold text-sm">
            iD
          </div>
          <div>
            <div className="font-syne font-bold text-sm text-[var(--ink)]">
              Open Researcher and Contributor ID (ORCID)
            </div>
            <div className="font-mono-code text-xs text-[var(--ink3)]">
              {PERSONAL_INFO.orcidId}
            </div>
          </div>
        </div>

        <a
          href={PERSONAL_INFO.orcidUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="px-4 py-2 border border-[var(--rule)] text-[var(--ink2)] hover:border-[var(--accent)] hover:text-[var(--accent)] hover:bg-[var(--accent-pale)] rounded text-xs font-mono-code flex items-center gap-1.5 transition-colors"
        >
          <span>View on ORCID.org</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>
    </div>
  );
};
