/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Search,
  Home,
  User,
  FolderGit2,
  Briefcase,
  Cpu,
  FileText,
  Mail,
  Send,
  ExternalLink,
  Copy,
  Check,
} from 'lucide-react';
import { PERSONAL_INFO } from '../../data/portfolioData';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (page: string) => void;
  onOpenEmailModal: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onOpenEmailModal,
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [copied, setCopied] = useState(false);

  const actions = [
    { id: 'home', label: 'Home', hint: 'Overview & bio', icon: Home, type: 'page' },
    { id: 'about', label: 'About', hint: 'Bio, education, languages', icon: User, type: 'page' },
    { id: 'projects', label: 'Projects', hint: 'Selected engineering works', icon: FolderGit2, type: 'page' },
    { id: 'experience', label: 'Experience', hint: 'Timeline & certifications', icon: Briefcase, type: 'page' },
    { id: 'skills', label: 'Skills', hint: 'Competencies & stack', icon: Cpu, type: 'page' },
    { id: 'research', label: 'Research', hint: 'Publications & problem statements', icon: FileText, type: 'page' },
    { id: 'contact', label: 'Contact', hint: 'Get in touch & location', icon: Mail, type: 'page' },
    {
      id: 'send-email',
      label: 'Send Email to Kishore',
      hint: 'Open mail transmission composer',
      icon: Send,
      type: 'action',
      handler: () => onOpenEmailModal(),
    },
    {
      id: 'copy-email',
      label: 'Copy Email Address',
      hint: PERSONAL_INFO.email,
      icon: Copy,
      type: 'action',
      handler: () => {
        navigator.clipboard.writeText(PERSONAL_INFO.email);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      },
    },
    {
      id: 'open-github',
      label: 'Visit GitHub Profile',
      hint: 'github.com/Kishorerm0602',
      icon: ExternalLink,
      type: 'action',
      handler: () => window.open(PERSONAL_INFO.githubUrl, '_blank'),
    },
  ];

  const filtered = actions.filter(
    (a) =>
      a.label.toLowerCase().includes(query.toLowerCase()) ||
      a.hint.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => Math.min(prev + 1, filtered.length - 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => Math.max(prev - 1, 0));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        const sel = filtered[selectedIndex];
        if (sel) {
          if (sel.type === 'page') {
            onNavigate(sel.id);
          } else if (sel.handler) {
            sel.handler();
          }
          onClose();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, filtered, selectedIndex, onNavigate, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-24 px-4 bg-black/60 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-[var(--surface)] text-[var(--ink)] border border-[var(--rule-strong)] rounded-lg shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-[var(--rule)]">
          <Search className="w-4 h-4 text-[var(--ink3)] flex-shrink-0" />
          <input
            autoFocus
            type="text"
            placeholder="Type a command or jump to section..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 bg-transparent border-none outline-none text-sm text-[var(--ink)] placeholder-[var(--ink4)] font-sans"
          />
          <kbd className="px-2 py-0.5 text-[10px] font-mono-code border border-[var(--rule)] rounded text-[var(--ink3)] bg-[var(--bg)]">
            esc
          </kbd>
        </div>

        {/* Results List */}
        <div className="max-h-80 overflow-y-auto p-2 space-y-1">
          {filtered.length === 0 ? (
            <div className="py-8 text-center text-xs font-mono-code text-[var(--ink3)]">
              No matching commands found.
            </div>
          ) : (
            filtered.map((item, idx) => {
              const Icon = item.icon;
              const isSelected = idx === selectedIndex;
              return (
                <div
                  key={item.id}
                  onClick={() => {
                    if (item.type === 'page') {
                      onNavigate(item.id);
                    } else if (item.handler) {
                      item.handler();
                    }
                    onClose();
                  }}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`flex items-center justify-between px-3 py-2.5 rounded-md cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-[var(--accent-pale)] text-[var(--accent)] font-medium'
                      : 'text-[var(--ink2)] hover:bg-[var(--bg2)]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isSelected ? 'text-[var(--accent)]' : 'text-[var(--ink3)]'}`} />
                    <span className="text-xs font-sans">{item.label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {item.id === 'copy-email' && copied && (
                      <span className="text-[10px] font-mono-code text-[var(--ok)] flex items-center gap-0.5">
                        <Check className="w-3 h-3" /> Copied
                      </span>
                    )}
                    <span className="text-[10px] font-mono-code text-[var(--ink4)]">{item.hint}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="px-4 py-2 bg-[var(--bg2)] border-t border-[var(--rule)] flex items-center justify-between text-[10px] font-mono-code text-[var(--ink3)]">
          <div className="flex items-center gap-3">
            <span>↑↓ Navigate</span>
            <span>↵ Select</span>
          </div>
          <span>Kishore R M · BME '29</span>
        </div>
      </div>
    </div>
  );
};
