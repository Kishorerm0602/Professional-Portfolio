/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Menu, Mail, ArrowUpRight } from 'lucide-react';
import { PERSONAL_INFO } from '../../data/portfolioData';

interface TopBarProps {
  activePage: string;
  onOpenMobileNav: () => void;
  onOpenEmailModal: () => void;
  onNavigateToContact: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  activePage,
  onOpenMobileNav,
  onOpenEmailModal,
  onNavigateToContact,
}) => {
  return (
    <header className="sticky top-0 z-30 h-14 bg-[var(--surface)] border-b border-[var(--rule)] px-4 sm:px-8 flex items-center justify-between backdrop-blur-md">
      {/* Left: Mobile Menu & Breadcrumbs */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobileNav}
          className="lg:hidden p-1.5 border border-[var(--rule)] rounded text-[var(--ink2)] hover:text-[var(--accent)] hover:border-[var(--accent)] transition-colors"
          title="Open Navigation"
        >
          <Menu className="w-4 h-4" />
        </button>

        <div className="font-mono-code text-xs text-[var(--ink3)] flex items-center gap-1.5">
          <span>portfolio</span>
          <span className="text-[var(--ink4)]">/</span>
          <span className="text-[var(--ink)] font-semibold uppercase tracking-wider text-[11px]">
            {activePage}
          </span>
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-2.5">
        {/* Send Email Action Button */}
        <button
          onClick={onOpenEmailModal}
          className="px-3.5 py-1.5 bg-[var(--vital-pale)] border border-[var(--vital)]/30 text-[var(--vital)] hover:bg-[var(--vital)] hover:text-white rounded text-[11px] font-mono-code font-medium transition-all shadow-sm flex items-center gap-1.5"
          title="Send Email to Kishore R M"
        >
          <Mail className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Send Email</span>
        </button>

        <button
          onClick={onNavigateToContact}
          className="px-3.5 py-1.5 border border-[var(--rule)] text-[var(--ink2)] hover:border-[var(--accent)] hover:text-[var(--accent)] hover:bg-[var(--accent-pale)] rounded text-[11px] font-mono-code font-medium transition-all"
        >
          Hire Me
        </button>

        <a
          href={PERSONAL_INFO.githubUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="px-4 py-1.5 bg-[var(--accent)] hover:bg-[var(--accent-lt)] text-white rounded text-[11px] font-mono-code font-medium transition-all shadow-sm flex items-center gap-1 group"
        >
          <span>GitHub</span>
          <ArrowUpRight className="w-3 h-3 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
        </a>
      </div>
    </header>
  );
};
