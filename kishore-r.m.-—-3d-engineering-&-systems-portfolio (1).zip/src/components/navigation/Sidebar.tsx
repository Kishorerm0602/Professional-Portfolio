/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Home,
  User,
  FolderGit2,
  Briefcase,
  Cpu,
  FileText,
  Mail,
  Moon,
  Sun,
  Search,
  ExternalLink,
} from 'lucide-react';
import { PERSONAL_INFO } from '../../data/portfolioData';

interface SidebarProps {
  activePage: string;
  onNavigate: (page: string) => void;
  isDark: boolean;
  onToggleTheme: () => void;
  onOpenCmdk: () => void;
  onOpenEmailModal: () => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activePage,
  onNavigate,
  isDark,
  onToggleTheme,
  onOpenCmdk,
  onOpenEmailModal,
  isOpenMobile,
  onCloseMobile,
}) => {
  const navItems = [
    { id: 'home', label: 'Home', icon: Home, key: '1' },
    { id: 'about', label: 'About', icon: User, key: '2' },
    { id: 'projects', label: 'Projects', icon: FolderGit2, key: '3' },
    { id: 'experience', label: 'Experience', icon: Briefcase, key: '4' },
    { id: 'skills', label: 'Skills', icon: Cpu, key: '5' },
    { id: 'research', label: 'Research', icon: FileText, key: '6' },
    { id: 'contact', label: 'Contact', icon: Mail, key: '7' },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm lg:hidden transition-opacity"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-[264px] bg-[var(--surface)] border-r border-[var(--rule)] flex flex-col transition-transform duration-300 ease-out lg:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Profile Card Header */}
        <div className="p-6 border-b border-[var(--rule)]">
          <div className="flex items-center gap-3.5 mb-3.5">
            <div className="relative w-13 h-13 rounded-full overflow-hidden border border-[var(--rule)] p-0.5 group">
              <img
                src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=200&q=80"
                alt="Kishore R M"
                className="w-full h-full object-cover rounded-full group-hover:scale-105 transition-transform"
              />
              <span className="absolute inset-0 rounded-full border border-[var(--vital)] opacity-40 pointer-events-none" />
            </div>

            <div className="min-w-0">
              <h1 className="font-syne font-bold text-base text-[var(--ink)] tracking-tight truncate">
                {PERSONAL_INFO.name}
              </h1>
              <p className="font-mono-code text-[11px] text-[var(--ink3)] truncate">
                {PERSONAL_INFO.title}
              </p>
            </div>
          </div>

          {/* Status Badge */}
          <div className="inline-flex items-center gap-2 font-mono-code text-[10.5px] text-[var(--ink3)]">
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--ok)] shadow-[0_0_0_2px_rgba(62,125,84,0.25)]" />
            <span>{PERSONAL_INFO.availability}</span>
          </div>

          {/* Command Palette Trigger Button */}
          <button
            onClick={onOpenCmdk}
            className="w-full mt-3.5 flex items-center justify-between px-3 py-2 bg-[var(--bg)] border border-[var(--rule)] rounded text-[11px] font-mono-code text-[var(--ink3)] hover:border-[var(--accent)] hover:text-[var(--accent)] transition-all group"
          >
            <div className="flex items-center gap-2">
              <Search className="w-3.5 h-3.5 text-[var(--ink3)] group-hover:text-[var(--accent)]" />
              <span>Quick jump</span>
            </div>
            <kbd className="px-1.5 py-0.5 border border-[var(--rule)] rounded text-[9px] text-[var(--ink4)] bg-[var(--surface)]">
              ⌘K
            </kbd>
          </button>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          <div className="px-3 mb-2 font-mono-code text-[9px] uppercase tracking-widest text-[var(--ink4)]">
            Navigation
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  onCloseMobile();
                }}
                className={`relative w-full flex items-center justify-between px-3 py-2 rounded text-[13.5px] transition-all font-sans text-left group ${
                  isActive
                    ? 'bg-[var(--accent-pale)] text-[var(--accent)] font-medium'
                    : 'text-[var(--ink3)] hover:bg-[var(--bg2)] hover:text-[var(--ink)]'
                }`}
              >
                {isActive && (
                  <span className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 bg-[var(--accent)] rounded-r" />
                )}
                <div className="flex items-center gap-2.5">
                  <Icon
                    className={`w-4 h-4 transition-colors ${
                      isActive ? 'text-[var(--accent)]' : 'text-[var(--ink3)] group-hover:text-[var(--ink)]'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>
                <span className="font-mono-code text-[10px] text-[var(--ink4)] opacity-0 group-hover:opacity-100 transition-opacity">
                  {item.key}
                </span>
              </button>
            );
          })}
        </nav>

        {/* Sidebar Footer Controls */}
        <div className="p-4 border-t border-[var(--rule)] bg-[var(--surface)] space-y-3">
          {/* Send via Email Action Trigger */}
          <button
            onClick={onOpenEmailModal}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-[var(--vital-pale)] border border-[var(--vital)]/30 text-[var(--vital)] hover:bg-[var(--vital)] hover:text-white rounded text-[11px] font-mono-code font-medium transition-all shadow-sm"
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Send via Email</span>
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={onToggleTheme}
            className="w-full flex items-center justify-between px-3 py-2 bg-[var(--bg)] border border-[var(--rule)] rounded text-[11px] font-mono-code text-[var(--ink3)] hover:border-[var(--accent)] hover:text-[var(--accent)] transition-all"
          >
            <span>{isDark ? 'Light mode' : 'Dark mode'}</span>
            {isDark ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
          </button>

          {/* Quick Contact Links */}
          <div className="space-y-1 pt-1 border-t border-[var(--rule)]">
            <a
              href={PERSONAL_INFO.githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-2 py-1 rounded text-[10px] font-mono-code text-[var(--ink3)] hover:text-[var(--accent)] hover:bg-[var(--accent-pale)] transition-colors truncate"
            >
              <ExternalLink className="w-3 h-3 flex-shrink-0" />
              <span className="truncate">{PERSONAL_INFO.githubUsername}</span>
            </a>

            <button
              onClick={onOpenEmailModal}
              className="w-full flex items-center gap-2 px-2 py-1 rounded text-[10px] font-mono-code text-[var(--ink3)] hover:text-[var(--accent)] hover:bg-[var(--accent-pale)] transition-colors truncate text-left"
            >
              <Mail className="w-3 h-3 flex-shrink-0" />
              <span className="truncate">{PERSONAL_INFO.email}</span>
            </button>

            <a
              href={PERSONAL_INFO.orcidUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-2 py-1 rounded text-[10px] font-mono-code text-[var(--ink3)] hover:text-[var(--accent)] hover:bg-[var(--accent-pale)] transition-colors truncate"
            >
              <span className="w-3 h-3 rounded-full bg-[#A6CE39] text-white flex items-center justify-center text-[7px] font-bold flex-shrink-0">
                iD
              </span>
              <span className="truncate">ORCID: {PERSONAL_INFO.orcidId}</span>
            </a>
          </div>
        </div>
      </aside>
    </>
  );
};
