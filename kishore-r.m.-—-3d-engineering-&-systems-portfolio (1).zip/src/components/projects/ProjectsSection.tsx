/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ExternalLink, Github, Filter, Sparkles } from 'lucide-react';
import { PROJECTS, ProjectData } from '../../data/portfolioData';

export const ProjectsSection: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState<string>('all');

  const filterOptions = ['all', 'Contribution', 'Full Stack', 'Frontend', 'Private'];

  const filteredProjects = PROJECTS.filter((p) => {
    if (activeFilter === 'all') return true;
    return p.badge === activeFilter;
  });

  return (
    <div className="p-8 sm:p-12 lg:p-16 max-w-7xl mx-auto">
      {/* Section Header */}
      <div className="mb-8">
        <div className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--accent)] mb-2 flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[var(--vital)]" />
          <span>// projects</span>
        </div>
        <h2 className="font-syne font-bold text-3xl sm:text-4xl text-[var(--ink)] tracking-tight mb-1">
          Selected Works
        </h2>
        <p className="font-epilogue italic text-sm text-[var(--ink3)]">
          Healthcare AI · Full-Stack · Open Source Contributions
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-2 mb-8">
        {filterOptions.map((filter) => (
          <button
            key={filter}
            onClick={() => setActiveFilter(filter)}
            className={`px-4 py-1.5 rounded text-[11px] font-mono-code uppercase tracking-wider transition-all border ${
              activeFilter === filter
                ? 'bg-[var(--accent)] border-[var(--accent)] text-white shadow-sm font-medium'
                : 'border-[var(--rule)] text-[var(--ink3)] hover:border-[var(--accent)] hover:text-[var(--accent)] bg-[var(--surface)]'
            }`}
          >
            {filter}
          </button>
        ))}
      </div>

      {/* Project Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-[1px] bg-[var(--rule)] border border-[var(--rule)] rounded-lg overflow-hidden">
        {filteredProjects.map((project, pIdx) => {
          const isWide = project.wide;
          const delayClass = `delay-${(pIdx % 4) + 1}`;
          return (
            <div
              key={project.id}
              className={`bg-[var(--surface)] hover:bg-[var(--bg)] transition-all flex flex-col group reveal-on-scroll ${delayClass} ${
                isWide ? 'md:col-span-2 md:grid md:grid-cols-[380px_1fr]' : ''
              }`}
            >
              {/* Image with Badge */}
              <div className="relative aspect-[16/10] md:aspect-auto overflow-hidden bg-black/10 min-h-[220px]">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover saturate-[0.85] group-hover:saturate-100 group-hover:scale-105 transition-all duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />

                {/* Badge */}
                <div className="absolute top-3.5 left-3.5 px-2.5 py-1 bg-black/85 backdrop-blur-md rounded text-[9.5px] font-mono-code uppercase tracking-wider text-white">
                  {project.badge}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 sm:p-7 flex flex-col justify-between flex-1">
                <div>
                  {/* Tech Stack Chips */}
                  <div className="flex flex-wrap gap-1.5 mb-3.5">
                    {project.tags.map((tag, tIdx) => (
                      <span
                        key={tIdx}
                        className="px-2 py-0.5 bg-[var(--bg2)] border border-[var(--rule)] rounded text-[9.5px] font-mono-code text-[var(--ink3)] group-hover:border-[var(--accent)]/30 transition-colors"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  <h3 className="font-syne font-bold text-xl text-[var(--ink)] tracking-tight mb-2 group-hover:text-[var(--accent)] transition-colors">
                    {project.title}
                  </h3>

                  <p className="text-xs sm:text-[13px] text-[var(--ink2)] leading-relaxed font-epilogue mb-4">
                    {project.description}
                  </p>

                  {project.biomedicalRelevance && (
                    <div className="mb-4 text-[11px] font-mono-code text-[var(--accent)] flex items-center gap-1.5 bg-[var(--accent-pale)] px-2.5 py-1 rounded border border-[var(--accent)]/15">
                      <Sparkles className="w-3 h-3 flex-shrink-0" />
                      <span>{project.biomedicalRelevance}</span>
                    </div>
                  )}
                </div>

                {/* Link */}
                <div className="pt-2">
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 font-mono-code text-[11px] uppercase tracking-wider text-[var(--accent)] hover:underline decoration-2 underline-offset-4 transition-transform group-hover:translate-x-1"
                  >
                    <Github className="w-3.5 h-3.5" />
                    <span>View on GitHub</span>
                    <ExternalLink className="w-3 h-3 ml-0.5" />
                  </a>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
