/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { ReactNode } from 'react';

interface RevealProps {
  children: ReactNode;
  animation?: 'slide-up' | 'slide-left' | 'slide-right' | 'scale';
  delay?: 1 | 2 | 3 | 4 | 5 | 6;
  className?: string;
}

export const Reveal: React.FC<RevealProps> = ({
  children,
  animation = 'slide-up',
  delay,
  className = '',
}) => {
  const animClass =
    animation === 'slide-left'
      ? 'reveal-slide-left'
      : animation === 'slide-right'
      ? 'reveal-slide-right'
      : animation === 'scale'
      ? 'reveal-scale'
      : 'reveal-on-scroll';

  const delayClass = delay ? `delay-${delay}` : '';

  return (
    <div className={`${animClass} ${delayClass} ${className}`}>
      {children}
    </div>
  );
};
