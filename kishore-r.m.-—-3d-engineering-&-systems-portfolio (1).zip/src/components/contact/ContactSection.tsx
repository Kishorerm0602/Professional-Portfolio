/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Mail,
  Send,
  Github,
  Linkedin,
  MapPin,
  ExternalLink,
  Copy,
  Check,
  Sparkles,
  ArrowRight,
  Terminal,
} from 'lucide-react';
import { PERSONAL_INFO } from '../../data/portfolioData';

interface ContactSectionProps {
  onOpenEmailModal: () => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ onOpenEmailModal }) => {
  const [inlineName, setInlineName] = useState('');
  const [inlineEmail, setInlineEmail] = useState('');
  const [inlineSubject, setInlineSubject] = useState('');
  const [inlineMessage, setInlineMessage] = useState('');
  const [inlineCategory, setInlineCategory] = useState('MedTech Internship Opportunity');
  const [copied, setCopied] = useState(false);
  const [sentSuccess, setSentSuccess] = useState(false);

  const handleInlineSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalSubject = encodeURIComponent(
      inlineSubject.trim() || `[${inlineCategory}] Contact from ${inlineName || 'Visitor'}`
    );
    const finalBody = encodeURIComponent(
      `Name: ${inlineName}\nEmail: ${inlineEmail}\nCategory: ${inlineCategory}\n\nMessage:\n${inlineMessage}`
    );
    window.location.href = `mailto:${PERSONAL_INFO.email}?subject=${finalSubject}&body=${finalBody}`;
    setSentSuccess(true);
  };

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(PERSONAL_INFO.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1.1fr_0.9fr] min-h-[calc(100vh-3.5rem)] bg-[var(--bg)]">
      {/* Left Column: Heading, Direct Send Email Form & Cards */}
      <div className="p-8 sm:p-12 lg:p-16 flex flex-col justify-center">
        <div className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--accent)] mb-3 flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[var(--vital)]" />
          <span>// contact</span>
        </div>

        <h2 className="font-syne font-extrabold text-4xl sm:text-5xl text-[var(--ink)] tracking-tight leading-[1.08] mb-4">
          Let's Build <br />
          Something <br />
          Together.
        </h2>

        <p className="text-sm text-[var(--ink2)] leading-relaxed max-w-lg mb-8 font-epilogue">
          Open to internships, research collaborations, and open-source projects in MedTech and Healthcare AI. Based in Chennai — open to remote work and relocation.
        </p>

        {/* Send via Email Interactive Form Panel */}
        <div className="p-6 bg-[var(--surface)] border border-[var(--rule)] rounded-lg shadow-sm mb-8 reveal-on-scroll delay-1">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-[var(--rule)]">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-[var(--accent)] text-white flex items-center justify-center">
                <Mail className="w-3.5 h-3.5" />
              </div>
              <div>
                <h3 className="font-syne font-bold text-sm text-[var(--ink)]">
                  Send via Email
                </h3>
                <span className="font-mono-code text-[10px] text-[var(--ink3)]">
                  Direct dispatch to {PERSONAL_INFO.email}
                </span>
              </div>
            </div>

            <button
              onClick={handleCopyEmail}
              className="px-2.5 py-1 border border-[var(--rule)] rounded text-[10px] font-mono-code text-[var(--ink3)] hover:text-[var(--accent)] hover:border-[var(--accent)] transition-colors flex items-center gap-1"
            >
              {copied ? <Check className="w-3 h-3 text-[var(--ok)]" /> : <Copy className="w-3 h-3" />}
              <span>{copied ? 'Copied' : 'Copy Email'}</span>
            </button>
          </div>

          {sentSuccess ? (
            <div className="py-6 text-center space-y-2">
              <div className="w-10 h-10 mx-auto rounded-full bg-[var(--ok-pale)] text-[var(--ok)] flex items-center justify-center">
                <Check className="w-5 h-5" />
              </div>
              <div className="font-syne font-bold text-base text-[var(--ink)]">
                Email Client Launched!
              </div>
              <p className="text-xs text-[var(--ink2)]">
                Your message is pre-filled and ready to send in your email client.
              </p>
              <button
                onClick={() => setSentSuccess(false)}
                className="mt-2 text-xs font-mono-code text-[var(--accent)] underline hover:text-[var(--accent-lt)]"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={handleInlineSubmit} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  placeholder="Your Name *"
                  value={inlineName}
                  onChange={(e) => setInlineName(e.target.value)}
                  className="px-3 py-2 bg-[var(--bg)] border border-[var(--rule)] rounded text-xs text-[var(--ink)] placeholder-[var(--ink4)] focus:outline-none focus:border-[var(--accent)]"
                />
                <input
                  type="email"
                  required
                  placeholder="Your Email *"
                  value={inlineEmail}
                  onChange={(e) => setInlineEmail(e.target.value)}
                  className="px-3 py-2 bg-[var(--bg)] border border-[var(--rule)] rounded text-xs text-[var(--ink)] placeholder-[var(--ink4)] focus:outline-none focus:border-[var(--accent)]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <select
                  value={inlineCategory}
                  onChange={(e) => setInlineCategory(e.target.value)}
                  className="px-3 py-2 bg-[var(--bg)] border border-[var(--rule)] rounded text-xs text-[var(--ink)] focus:outline-none focus:border-[var(--accent)] font-mono-code"
                >
                  <option value="MedTech Internship Opportunity">MedTech Internship</option>
                  <option value="Healthcare AI & Research">Healthcare AI Research</option>
                  <option value="Open Source Collaboration (GSSoC)">Open Source (GSSoC)</option>
                  <option value="Full-Stack Web Project">Full-Stack Project</option>
                </select>

                <input
                  type="text"
                  placeholder="Subject Line"
                  value={inlineSubject}
                  onChange={(e) => setInlineSubject(e.target.value)}
                  className="px-3 py-2 bg-[var(--bg)] border border-[var(--rule)] rounded text-xs text-[var(--ink)] placeholder-[var(--ink4)] focus:outline-none focus:border-[var(--accent)]"
                />
              </div>

              <textarea
                required
                rows={3}
                placeholder="Write your message to Kishore..."
                value={inlineMessage}
                onChange={(e) => setInlineMessage(e.target.value)}
                className="w-full px-3 py-2 bg-[var(--bg)] border border-[var(--rule)] rounded text-xs text-[var(--ink)] placeholder-[var(--ink4)] focus:outline-none focus:border-[var(--accent)] resize-none"
              />

              <div className="flex items-center justify-between pt-1">
                <button
                  type="button"
                  onClick={onOpenEmailModal}
                  className="text-[11px] font-mono-code text-[var(--accent)] hover:underline flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Open Advanced Composer</span>
                </button>

                <button
                  type="submit"
                  className="px-4 py-2 bg-[var(--accent)] hover:bg-[var(--accent-lt)] text-white rounded text-xs font-mono-code font-medium transition-all shadow-sm flex items-center gap-1.5"
                >
                  <Send className="w-3 h-3" />
                  <span>Send via Email</span>
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Contact Links Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 reveal-on-scroll delay-2">
          {/* Email Item */}
          <button
            onClick={onOpenEmailModal}
            className="p-3.5 bg-[var(--surface)] border border-[var(--rule)] rounded-md hover:border-[var(--accent)] transition-all flex items-center gap-3 text-left group"
          >
            <div className="w-9 h-9 rounded-full bg-[var(--bg2)] group-hover:bg-[var(--accent)] group-hover:text-white transition-colors flex items-center justify-center flex-shrink-0 text-[var(--ink2)]">
              <Mail className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="font-mono-code text-[10px] text-[var(--ink3)]">Email</div>
              <div className="text-xs font-medium text-[var(--ink)] truncate group-hover:text-[var(--accent)] transition-colors">
                {PERSONAL_INFO.email}
              </div>
            </div>
          </button>

          {/* GitHub Item */}
          <a
            href={PERSONAL_INFO.githubUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3.5 bg-[var(--surface)] border border-[var(--rule)] rounded-md hover:border-[var(--accent)] transition-all flex items-center gap-3 group"
          >
            <div className="w-9 h-9 rounded-full bg-[var(--bg2)] group-hover:bg-[var(--accent)] group-hover:text-white transition-colors flex items-center justify-center flex-shrink-0 text-[var(--ink2)]">
              <Github className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="font-mono-code text-[10px] text-[var(--ink3)]">GitHub</div>
              <div className="text-xs font-medium text-[var(--ink)] truncate group-hover:text-[var(--accent)] transition-colors">
                github.com/{PERSONAL_INFO.githubUsername}
              </div>
            </div>
          </a>

          {/* LinkedIn Item */}
          <a
            href={PERSONAL_INFO.linkedinUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3.5 bg-[var(--surface)] border border-[var(--rule)] rounded-md hover:border-[var(--accent)] transition-all flex items-center gap-3 group"
          >
            <div className="w-9 h-9 rounded-full bg-[var(--bg2)] group-hover:bg-[var(--accent)] group-hover:text-white transition-colors flex items-center justify-center flex-shrink-0 text-[var(--ink2)]">
              <Linkedin className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="font-mono-code text-[10px] text-[var(--ink3)]">LinkedIn</div>
              <div className="text-xs font-medium text-[var(--ink)] truncate group-hover:text-[var(--accent)] transition-colors">
                linkedin.com/in/kishore-rm
              </div>
            </div>
          </a>

          {/* ORCID Item */}
          <a
            href={PERSONAL_INFO.orcidUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3.5 bg-[var(--surface)] border border-[var(--rule)] rounded-md hover:border-[var(--accent)] transition-all flex items-center gap-3 group"
          >
            <div className="w-9 h-9 rounded-full bg-[var(--bg2)] group-hover:bg-[#A6CE39] group-hover:text-white transition-colors flex items-center justify-center flex-shrink-0 text-[var(--ink2)]">
              <span className="font-mono font-bold text-xs">iD</span>
            </div>
            <div className="min-w-0">
              <div className="font-mono-code text-[10px] text-[var(--ink3)]">ORCID</div>
              <div className="text-xs font-medium text-[var(--ink)] truncate group-hover:text-[var(--accent)] transition-colors">
                {PERSONAL_INFO.orcidId}
              </div>
            </div>
          </a>

          {/* Location Item */}
          <div className="p-3.5 bg-[var(--surface)] border border-[var(--rule)] rounded-md flex items-center gap-3 sm:col-span-2">
            <div className="w-9 h-9 rounded-full bg-[var(--bg2)] flex items-center justify-center flex-shrink-0 text-[var(--ink2)]">
              <MapPin className="w-4 h-4 text-[var(--vital)]" />
            </div>
            <div>
              <div className="font-mono-code text-[10px] text-[var(--ink3)]">Location</div>
              <div className="text-xs font-medium text-[var(--ink)]">
                {PERSONAL_INFO.location} · {PERSONAL_INFO.neighborhood}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Column: Animated Vital ECG Bar & Telemetry Status Terminal */}
      <div className="bg-[var(--mono-bg)] text-[var(--mono-text)] p-8 sm:p-12 lg:p-16 flex flex-col justify-center relative overflow-hidden border-t lg:border-t-0 lg:border-l border-[var(--rule)]">
        {/* Subtle vital gradient line */}
        <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-[var(--vital)] to-transparent opacity-30" />

        {/* Vital ECG Pulse Graph */}
        <div className="w-full h-20 mb-8" aria-hidden="true">
          <svg viewBox="0 0 380 80" preserveAspectRatio="none" className="w-full h-full">
            <path className="vital-track" d="M0,40 L380,40" />
            <path
              className="vital-path vital-anim"
              d="M0,40 L60,40 L72,15 L86,65 L98,40 L160,40 L172,22 L184,58 L196,40 L260,40 L272,12 L286,68 L298,40 L380,40"
            />
          </svg>
        </div>

        {/* Status Log Box */}
        <div className="font-mono text-xs leading-loose space-y-1 bg-[var(--mono-bg2)] p-6 rounded-md border border-white/5 reveal-slide-right delay-2">
          <div className="text-[var(--mono-green)] font-semibold flex items-center justify-between pb-2 border-b border-white/5">
            <span># status.log · Clinical Telemetry</span>
            <span className="text-[10px] text-white/40">NODE_ONLINE</span>
          </div>

          <div className="pt-2">
            <span className="text-[var(--mono-orange)]">"availability"</span>: <span className="text-[var(--mono-green)]">true</span>,
          </div>
          <div>
            <span className="text-[var(--mono-orange)]">"response_time"</span>: <span className="text-[var(--mono-green)]">"~24h"</span>,
          </div>
          <div>
            <span className="text-[var(--mono-orange)]">"timezone"</span>: <span className="text-[var(--mono-green)]">"IST (UTC+5:30)"</span>,
          </div>
          <div>
            <span className="text-[var(--mono-orange)]">"open_to"</span>: [<span className="text-[var(--mono-green)]">"internships"</span>, <span className="text-[var(--mono-green)]">"research"</span>, <span className="text-[var(--mono-green)]">"oss"</span>],
          </div>
          <div>
            <span className="text-[var(--mono-orange)]">"email_target"</span>: <span className="text-[#9CDCFE]">"{PERSONAL_INFO.email}"</span>
          </div>
        </div>

        <div className="mt-8 pt-4 border-t border-white/5 flex items-center justify-between font-mono text-[11px] text-white/40">
          <span>J.N.N Institute of Engineering</span>
          <span>Chennai, India</span>
        </div>
      </div>
    </div>
  );
};
