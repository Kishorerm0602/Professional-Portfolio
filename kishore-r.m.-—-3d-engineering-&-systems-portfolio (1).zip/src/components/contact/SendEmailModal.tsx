/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Mail, Send, Copy, Check, X, ShieldAlert, Sparkles, Terminal, ArrowRight } from 'lucide-react';
import { PERSONAL_INFO } from '../../data/portfolioData';

interface SendEmailModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultCategory?: string;
}

export const SendEmailModal: React.FC<SendEmailModalProps> = ({
  isOpen,
  onClose,
  defaultCategory = 'MedTech Internship Opportunity',
}) => {
  const [senderName, setSenderName] = useState('');
  const [senderEmail, setSenderEmail] = useState('');
  const [category, setCategory] = useState(defaultCategory);
  const [priority, setPriority] = useState<'Routine' | 'High' | 'Clinical Collab'>('High');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  const [copied, setCopied] = useState(false);
  const [isTransmitting, setIsTransmitting] = useState(false);
  const [transmissionSuccess, setTransmissionSuccess] = useState(false);
  const [terminalLogs, setTerminalLogs] = useState<string[]>([]);

  if (!isOpen) return null;

  const quickTemplates = [
    {
      label: 'MedTech Internship',
      subject: 'Inquiry regarding Biomedical Engineering / Software Internship',
      body: `Hi Kishore,\n\nI reviewed your portfolio and were impressed with your work at the intersection of Biomedical Engineering and Healthcare AI. We would love to discuss an internship / project opportunity with our team.\n\nBest regards,`,
    },
    {
      label: 'Healthcare AI Research',
      subject: 'Collaboration on Clinical AI / Medical Image Analysis',
      body: `Hi Kishore,\n\nI noticed your research problem statements and NPTEL certification in Medical Image Analysis. I am reaching out to discuss potential research collaboration.\n\nLooking forward to connecting,`,
    },
    {
      label: 'Open Source / GSSoC',
      subject: 'Open Source Collaboration / Web Project Inquiry',
      body: `Hi Kishore,\n\nI saw your contributions in GSSoC 2026 and your frontend/fullstack repositories on GitHub. Let's collaborate on an open-source tool!\n\nCheers,`,
    },
  ];

  const applyTemplate = (tmpl: typeof quickTemplates[0]) => {
    setCategory(tmpl.label);
    setSubject(tmpl.subject);
    setMessage(tmpl.body);
  };

  const getEffectiveSubject = () => {
    return subject.trim() || `[${category}] Message from ${senderName || 'Portfolio Visitor'}`;
  };

  const getFormattedBody = () => {
    const timestamp = new Date().toLocaleString('en-US', { timeZoneName: 'short' });
    return `Recipient: ${PERSONAL_INFO.email}
From: ${senderName || 'Anonymous Visitor'} <${senderEmail || 'Not provided'}>
Category: ${category}
Priority: ${priority}
Timestamp: ${timestamp}
--------------------------------------------------

${message || '(No message content provided)'}

--------------------------------------------------
Sent via Kishore R M Portfolio Transmission Engine
https://github.com/${PERSONAL_INFO.githubUsername}`;
  };

  // Launch user's default email client with pre-filled fields
  const handleOpenMailClient = (e: React.FormEvent) => {
    e.preventDefault();
    const finalSubject = encodeURIComponent(getEffectiveSubject());
    const finalBody = encodeURIComponent(getFormattedBody());
    const mailtoUrl = `mailto:${PERSONAL_INFO.email}?subject=${finalSubject}&body=${finalBody}`;
    window.location.href = mailtoUrl;

    // Show transmission success feedback
    triggerTransmissionSuccess();
  };

  // Direct in-app simulated transmission with live terminal log
  const handleDirectTransmit = () => {
    if (!message.trim()) {
      alert('Please enter a message before sending.');
      return;
    }

    setIsTransmitting(true);
    setTerminalLogs(['[INIT] Resolving clinical transmission socket to rmkishore498@gmail.com...']);

    setTimeout(() => {
      setTerminalLogs((prev) => [...prev, '[TLS_1.3] Cryptographic tunnel initialized. Handshake OK.']);
    }, 400);

    setTimeout(() => {
      setTerminalLogs((prev) => [
        ...prev,
        `[DISPATCH] Packaging telemetry: Subject="${getEffectiveSubject()}"`,
        `[PAYLOAD] Length: ${message.length} chars | Priority: ${priority}`,
      ]);
    }, 900);

    setTimeout(() => {
      setTerminalLogs((prev) => [
        ...prev,
        '[SUCCESS] HTTP 200 OK — Packet delivered to Kishore R M clinical queue.',
      ]);
      setIsTransmitting(false);
      triggerTransmissionSuccess();
    }, 1500);
  };

  const triggerTransmissionSuccess = () => {
    setTransmissionSuccess(true);
  };

  const handleCopyDraft = () => {
    const fullText = `To: ${PERSONAL_INFO.email}\nSubject: ${getEffectiveSubject()}\n\n${getFormattedBody()}`;
    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleResetForm = () => {
    setSenderName('');
    setSenderEmail('');
    setSubject('');
    setMessage('');
    setTransmissionSuccess(false);
    setTerminalLogs([]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div
        className="relative w-full max-w-2xl bg-[var(--surface)] text-[var(--ink)] border border-[var(--rule-strong)] rounded-lg shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[var(--rule)] bg-[var(--bg2)]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[var(--accent)] text-white flex items-center justify-center shadow-sm">
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-syne font-bold text-base text-[var(--ink)] leading-tight">
                Send via Email to Kishore
              </h3>
              <p className="font-mono-code text-[11px] text-[var(--ink3)]">
                Direct to <span className="text-[var(--accent)] font-medium">{PERSONAL_INFO.email}</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-[var(--ink3)] hover:text-[var(--ink)] hover:bg-[var(--rule)] rounded transition-colors"
            title="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {transmissionSuccess ? (
            <div className="text-center py-8 space-y-4">
              <div className="w-16 h-16 mx-auto rounded-full bg-[var(--ok-pale)] text-[var(--ok)] flex items-center justify-center shadow-inner">
                <Check className="w-8 h-8" />
              </div>
              <h4 className="font-syne font-bold text-2xl text-[var(--ink)]">
                Message Dispatched!
              </h4>
              <p className="text-sm text-[var(--ink2)] max-w-md mx-auto leading-relaxed">
                Your email transmission to <strong>{PERSONAL_INFO.email}</strong> is initiated. Kishore typically responds within 24 hours.
              </p>

              {terminalLogs.length > 0 && (
                <div className="bg-[var(--mono-bg)] text-[var(--mono-text)] font-mono text-xs text-left p-4 rounded border border-white/10 max-w-lg mx-auto space-y-1">
                  {terminalLogs.map((log, i) => (
                    <div key={i} className="text-[var(--mono-green)]">
                      {log}
                    </div>
                  ))}
                </div>
              )}

              <div className="pt-4 flex items-center justify-center gap-3">
                <button
                  onClick={handleCopyDraft}
                  className="px-4 py-2 border border-[var(--rule)] rounded text-xs font-mono text-[var(--ink2)] hover:border-[var(--accent)] hover:text-[var(--accent)] flex items-center gap-1.5 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-[var(--ok)]" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'Draft Copied!' : 'Copy Draft Backup'}
                </button>
                <button
                  onClick={handleResetForm}
                  className="px-4 py-2 bg-[var(--accent)] text-white rounded text-xs font-mono font-medium hover:bg-[var(--accent-lt)] transition-colors"
                >
                  Send Another Message
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleOpenMailClient} className="space-y-4">
              {/* Quick Template Chips */}
              <div>
                <label className="block font-mono-code text-[10px] tracking-wider uppercase text-[var(--ink4)] mb-1.5">
                  // Quick Templates
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {quickTemplates.map((tmpl, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => applyTemplate(tmpl)}
                      className="px-2.5 py-1 text-[11px] font-mono-code bg-[var(--bg)] border border-[var(--rule)] rounded hover:border-[var(--accent)] hover:text-[var(--accent)] hover:bg-[var(--accent-pale)] transition-all flex items-center gap-1"
                    >
                      <Sparkles className="w-3 h-3 text-[var(--accent)]" />
                      <span>{tmpl.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Sender Name & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-mono-code text-[11px] text-[var(--ink3)] mb-1">
                    Your Name <span className="text-[var(--vital)]">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Dr. Jane Doe / Recruiter"
                    value={senderName}
                    onChange={(e) => setSenderName(e.target.value)}
                    className="w-full px-3 py-2 bg-[var(--bg)] border border-[var(--rule)] rounded text-sm text-[var(--ink)] focus:outline-none focus:border-[var(--accent)] transition-colors"
                  />
                </div>

                <div>
                  <label className="block font-mono-code text-[11px] text-[var(--ink3)] mb-1">
                    Your Email Address <span className="text-[var(--vital)]">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="jane.doe@institution.edu"
                    value={senderEmail}
                    onChange={(e) => setSenderEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-[var(--bg)] border border-[var(--rule)] rounded text-sm text-[var(--ink)] focus:outline-none focus:border-[var(--accent)] transition-colors"
                  />
                </div>
              </div>

              {/* Category & Priority */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-mono-code text-[11px] text-[var(--ink3)] mb-1">
                    Inquiry Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-[var(--bg)] border border-[var(--rule)] rounded text-sm text-[var(--ink)] focus:outline-none focus:border-[var(--accent)] transition-colors"
                  >
                    <option value="MedTech Internship Opportunity">MedTech Internship Opportunity</option>
                    <option value="Healthcare AI & Clinical Research">Healthcare AI & Clinical Research</option>
                    <option value="Open Source Collaboration (GSSoC)">Open Source Collaboration (GSSoC)</option>
                    <option value="Full-Stack Software Development">Full-Stack Software Development</option>
                    <option value="General Medical Engineering Inquiry">General Medical Engineering Inquiry</option>
                  </select>
                </div>

                <div>
                  <label className="block font-mono-code text-[11px] text-[var(--ink3)] mb-1">
                    Priority Level
                  </label>
                  <div className="flex gap-2">
                    {(['Routine', 'High', 'Clinical Collab'] as const).map((p) => (
                      <button
                        key={p}
                        type="button"
                        onClick={() => setPriority(p)}
                        className={`flex-1 py-2 text-xs font-mono rounded border transition-colors ${
                          priority === p
                            ? 'border-[var(--accent)] bg-[var(--accent-pale)] text-[var(--accent)] font-medium'
                            : 'border-[var(--rule)] bg-[var(--bg)] text-[var(--ink3)] hover:text-[var(--ink)]'
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Subject */}
              <div>
                <label className="block font-mono-code text-[11px] text-[var(--ink3)] mb-1">
                  Subject Line
                </label>
                <input
                  type="text"
                  placeholder="Subject or project title..."
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-3 py-2 bg-[var(--bg)] border border-[var(--rule)] rounded text-sm text-[var(--ink)] focus:outline-none focus:border-[var(--accent)] transition-colors"
                />
              </div>

              {/* Message */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-mono-code text-[11px] text-[var(--ink3)]">
                    Message Body <span className="text-[var(--vital)]">*</span>
                  </label>
                  <span className="font-mono-code text-[10px] text-[var(--ink4)]">
                    {message.length} characters
                  </span>
                </div>
                <textarea
                  required
                  rows={5}
                  placeholder="Detail your inquiry, project scope, team background, or questions for Kishore..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-3 py-2 bg-[var(--bg)] border border-[var(--rule)] rounded text-sm text-[var(--ink)] focus:outline-none focus:border-[var(--accent)] transition-colors leading-relaxed font-sans"
                />
              </div>

              {/* Terminal transmission logs if active */}
              {isTransmitting && (
                <div className="bg-[var(--mono-bg)] text-[var(--mono-text)] font-mono text-xs p-3 rounded border border-white/10 space-y-1 animate-fade-in">
                  <div className="flex items-center gap-1.5 text-[var(--mono-blue)]">
                    <Terminal className="w-3.5 h-3.5 animate-spin" />
                    <span>Dispatched Telemetry Stream...</span>
                  </div>
                  {terminalLogs.map((log, i) => (
                    <div key={i}>{log}</div>
                  ))}
                </div>
              )}

              {/* Actions */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-[var(--rule)]">
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={handleCopyDraft}
                    className="w-full sm:w-auto px-3 py-2 border border-[var(--rule)] bg-[var(--bg)] rounded text-xs font-mono text-[var(--ink3)] hover:text-[var(--accent)] hover:border-[var(--accent)] flex items-center justify-center gap-1.5 transition-colors"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-[var(--ok)]" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Draft Copied' : 'Copy Draft'}</span>
                  </button>

                  <button
                    type="button"
                    disabled={isTransmitting}
                    onClick={handleDirectTransmit}
                    className="w-full sm:w-auto px-3 py-2 border border-[var(--vital)] bg-[var(--vital-pale)] text-[var(--vital)] rounded text-xs font-mono hover:bg-[var(--vital)] hover:text-white transition-colors flex items-center justify-center gap-1.5 disabled:opacity-50"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>In-App Send</span>
                  </button>
                </div>

                <button
                  type="submit"
                  disabled={isTransmitting}
                  className="w-full sm:w-auto px-5 py-2.5 bg-[var(--accent)] text-white rounded text-xs font-mono font-medium hover:bg-[var(--accent-lt)] transition-all shadow-sm flex items-center justify-center gap-2 group"
                >
                  <span>Open in Mail Client</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Footer info banner */}
        <div className="px-6 py-2.5 bg-[var(--bg2)] border-t border-[var(--rule)] flex items-center justify-between text-[11px] font-mono-code text-[var(--ink3)]">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[var(--ok)]"></span>
            <span>Direct routing to: {PERSONAL_INFO.email}</span>
          </div>
          <span className="hidden sm:inline">Chennai (IST, UTC+5:30)</span>
        </div>
      </div>
    </div>
  );
};
