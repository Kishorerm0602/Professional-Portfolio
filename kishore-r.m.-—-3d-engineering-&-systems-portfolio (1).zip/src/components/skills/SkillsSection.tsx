/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SKILL_CATEGORIES, TOOLS_LIST, DOMAIN_KNOWLEDGE_LIST } from '../../data/portfolioData';
import { BiomedicalScene } from '../3d/BiomedicalScene';
import { Sparkles, Cpu, Layers } from 'lucide-react';

export const SkillsSection: React.FC = () => {
  const [show3dWidget, setShow3dWidget] = useState(false);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_1fr] min-h-[calc(100vh-3.5rem)] bg-[var(--rule)] gap-[1px]">
      {/* Left Column: Skill Competency Tracks */}
      <div className="p-8 sm:p-12 lg:p-14 bg-[var(--surface)]">
        <div className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--accent)] mb-2 flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[var(--vital)]" />
          <span>// skills</span>
        </div>

        <h2 className="font-syne font-bold text-3xl sm:text-4xl text-[var(--ink)] tracking-tight mb-2">
          Technical Competencies
        </h2>
        <p className="font-epilogue italic text-sm text-[var(--ink3)] mb-10">
          Biomedical science meets modern software engineering
        </p>

        {/* Skill Groups */}
        <div className="space-y-8">
          {SKILL_CATEGORIES.map((category, catIdx) => (
            <div key={catIdx} className={`reveal-on-scroll delay-${catIdx + 1}`}>
              <div className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--ink3)] pb-2 border-b border-[var(--rule)] mb-4 font-semibold">
                {category.title}
              </div>

              <div className="space-y-3.5">
                {category.skills.map((skill, sIdx) => (
                  <div key={sIdx} className="space-y-1 group">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-[var(--ink2)] group-hover:text-[var(--ink)] transition-colors">
                        {skill.name}
                      </span>
                      <span className="font-mono-code text-[10.5px] text-[var(--ink3)] font-medium">
                        {skill.percentage}%
                      </span>
                    </div>

                    <div className="h-1.5 bg-[var(--rule)] rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-1000 ${
                          skill.warm ? 'bg-[var(--vital)]' : 'bg-[var(--accent)]'
                        }`}
                        style={{ width: `${skill.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Right Column: Stack Snapshot & Tools Ecosystem */}
      <div className="p-8 sm:p-12 bg-[var(--bg2)] flex flex-col justify-between space-y-8">
        <div>
          {/* Tech Image / 3D Toggle */}
          <div className="mb-8 reveal-on-scroll delay-1">
            <div className="flex items-center justify-between mb-2">
              <span className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--ink3)] font-semibold">
                {show3dWidget ? 'Interactive 3D Biomedical Node' : '// Stack Snapshot'}
              </span>
              <button
                onClick={() => setShow3dWidget(!show3dWidget)}
                className="flex items-center gap-1 font-mono-code text-[10.5px] text-[var(--accent)] hover:underline"
              >
                <Sparkles className="w-3 h-3" />
                <span>{show3dWidget ? 'Show Hardware Photo' : 'Launch 3D Visualizer'}</span>
              </button>
            </div>

            {show3dWidget ? (
              <div className="h-64 rounded-md overflow-hidden border border-[var(--rule)] shadow-sm">
                <BiomedicalScene compact initialMode="neural" />
              </div>
            ) : (
              <div className="relative aspect-[16/7] rounded-md overflow-hidden border border-[var(--rule)] shadow-sm group">
                <img
                  src="https://images.unsplash.com/photo-1518770660439-4636190af475?w=700&q=80"
                  alt="Technology and Circuits"
                  className="w-full h-full object-cover saturate-[0.8] group-hover:saturate-100 transition-all duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent flex items-end p-4">
                  <span className="font-mono-code text-white text-[11px] uppercase tracking-wider font-medium">
                    // Clinical Hardware & Systems Architecture
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Tools Grid */}
          <div className="mb-8 reveal-on-scroll delay-2">
            <div className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--ink3)] pb-2.5 border-b border-[var(--rule)] mb-3.5 font-semibold">
              Tools & Ecosystem
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {TOOLS_LIST.map((tool, idx) => (
                <div
                  key={idx}
                  className="px-3 py-2 bg-[var(--surface)] border border-[var(--rule)] rounded text-center font-mono-code text-[10.5px] text-[var(--ink2)] hover:border-[var(--accent)] hover:text-[var(--accent)] hover:bg-[var(--accent-pale)] transition-all cursor-default"
                >
                  {tool}
                </div>
              ))}
            </div>
          </div>

          {/* Domain Knowledge Pills */}
          <div className="reveal-on-scroll delay-3">
            <div className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--ink3)] pb-2.5 border-b border-[var(--rule)] mb-3 font-semibold">
              Domain Knowledge
            </div>
            <div className="flex flex-wrap gap-2">
              {DOMAIN_KNOWLEDGE_LIST.map((domain, idx) => (
                <span
                  key={idx}
                  className="px-3.5 py-1.5 bg-[var(--surface)] border border-[var(--rule)] rounded text-xs text-[var(--ink2)] hover:border-[var(--accent)] hover:text-[var(--accent)] hover:bg-[var(--accent-pale)] transition-colors cursor-default"
                >
                  {domain}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Note */}
        <div className="p-4 bg-[var(--surface)] border border-[var(--rule)] rounded text-xs text-[var(--ink3)] font-epilogue leading-relaxed">
          <strong className="text-[var(--ink)] block font-syne mb-1 font-semibold">
            Biomedical Instrumentation Focus
          </strong>
          Trained in signal acquisition, analog circuit modeling, medical imaging reconstruction algorithms, and secure clinical data interoperability (HL7/FHIR).
        </div>
      </div>
    </div>
  );
};
