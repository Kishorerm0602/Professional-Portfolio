/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';

export const HeroTerminal: React.FC = () => {
  const terminalLines = [
    { t: '# Kishore R M — Profile', type: 'comment' },
    { t: '', type: 'empty' },
    { t: 'class KishoreRM:', type: 'class' },
    { t: '    name = "Kishore R M"', type: 'var', key: 'name', val: '"Kishore R M"' },
    { t: '    role = "BME Student + Developer"', type: 'var', key: 'role', val: '"BME Student + Developer"' },
    { t: '    institute = "JNNIE Chennai"', type: 'var', key: 'institute', val: '"JNNIE Chennai"' },
    { t: '    batch = "2025–2029"', type: 'var', key: 'batch', val: '"2025–2029"' },
    { t: '    github = "Kishorerm0602"', type: 'var', key: 'github', val: '"Kishorerm0602"' },
    { t: '', type: 'empty' },
    { t: '    focus_areas = [', type: 'list-start', key: 'focus_areas' },
    { t: '        "Healthcare AI",', type: 'list-item', val: '"Healthcare AI"' },
    { t: '        "Medical Image Analysis",', type: 'list-item', val: '"Medical Image Analysis"' },
    { t: '        "AIML & Deep Learning",', type: 'list-item', val: '"AIML & Deep Learning"' },
    { t: '        "Internet of Things",', type: 'list-item', val: '"Internet of Things"' },
    { t: '        "Open Source (GSSoC \'26)",', type: 'list-item', val: '"Open Source (GSSoC \'26)"' },
    { t: '    ]', type: 'list-end' },
    { t: '', type: 'empty' },
    { t: '    targeting = [', type: 'list-start', key: 'targeting' },
    { t: '        "GE HealthCare",', type: 'list-item', val: '"GE HealthCare"' },
    { t: '        "Siemens Healthineers",', type: 'list-item', val: '"Siemens Healthineers"' },
    { t: '        "Philips",', type: 'list-item', val: '"Philips"' },
    { t: '    ]', type: 'list-end' },
    { t: '', type: 'empty' },
    { t: '    def greet(self):', type: 'func' },
    { t: '        return "Let\'s build something."', type: 'return', val: '"Let\'s build something."' },
    { t: '', type: 'empty' },
    { t: '>>> live status: ACTIVE', type: 'prompt' },
  ];

  const [visibleCount, setVisibleCount] = useState(1);

  useEffect(() => {
    if (visibleCount >= terminalLines.length) return;
    const timer = setTimeout(() => {
      setVisibleCount((prev) => prev + 1);
    }, 45);
    return () => clearTimeout(timer);
  }, [visibleCount, terminalLines.length]);

  return (
    <div className="flex flex-col h-full bg-[var(--mono-bg)] text-[var(--mono-text)] border border-[var(--rule)] rounded-md overflow-hidden relative font-mono text-[12.5px]">
      {/* Top window bar */}
      <div className="flex items-center gap-1.5 px-4 py-3 bg-[var(--mono-bg2)] border-b border-white/5">
        <div className="w-2.5 h-2.5 rounded-full bg-[#FF5F57]" />
        <div className="w-2.5 h-2.5 rounded-full bg-[#FFBD2E]" />
        <div className="w-2.5 h-2.5 rounded-full bg-[#28C840]" />
        <span className="ml-2 font-mono text-[11px] text-white/35">
          kishore_rm · profile.py
        </span>
      </div>

      {/* Code body */}
      <div className="flex-1 p-5 overflow-auto space-y-1 leading-relaxed">
        {terminalLines.slice(0, visibleCount).map((line, idx) => {
          if (line.type === 'comment') {
            return (
              <div key={idx} className="text-[var(--mono-green)]">
                {line.t}
              </div>
            );
          }
          if (line.type === 'empty') {
            return <div key={idx} className="h-2" />;
          }
          if (line.type === 'class') {
            return (
              <div key={idx}>
                <span className="text-[var(--mono-blue)]">class </span>
                <span className="text-[#DCDCAA]">KishoreRM</span>:
              </div>
            );
          }
          if (line.type === 'var') {
            return (
              <div key={idx}>
                <span className="text-[#9CDCFE]">    {line.key}</span> ={' '}
                <span className="text-[var(--mono-orange)]">{line.val}</span>
              </div>
            );
          }
          if (line.type === 'list-start') {
            return (
              <div key={idx}>
                <span className="text-[#9CDCFE]">    {line.key}</span> = [
              </div>
            );
          }
          if (line.type === 'list-item') {
            return (
              <div key={idx}>
                <span className="text-[var(--mono-orange)]">        {line.val}</span>
              </div>
            );
          }
          if (line.type === 'list-end') {
            return <div key={idx}>    ]</div>;
          }
          if (line.type === 'func') {
            return (
              <div key={idx}>
                <span className="text-[var(--mono-blue)]">    def </span>
                <span className="text-[#DCDCAA]">greet</span>(
                <span className="text-[#9CDCFE]">self</span>):
              </div>
            );
          }
          if (line.type === 'return') {
            return (
              <div key={idx}>
                <span className="text-[var(--mono-purple)]">        return </span>
                <span className="text-[var(--mono-orange)]">{line.val}</span>
              </div>
            );
          }
          if (line.type === 'prompt') {
            return (
              <div key={idx} className="text-white/40 pt-1">
                &gt;&gt;&gt;{' '}
                <span className="text-[var(--mono-green)]">telemetry ready</span>
                <span className="typing-cursor" />
              </div>
            );
          }
          return <div key={idx}>{line.t}</div>;
        })}

        {visibleCount < terminalLines.length && (
          <div className="text-white/40">
            &gt;&gt;&gt; <span className="typing-cursor" />
          </div>
        )}
      </div>

      {/* Terminal Readout Bar */}
      <div className="border-t border-white/5 px-5 py-3 grid grid-cols-2 gap-4 bg-[var(--mono-bg2)]">
        <div>
          <div className="font-mono text-[9px] uppercase tracking-widest text-white/40">
            Status
          </div>
          <div className="font-mono text-xs text-[var(--mono-green)] flex items-center gap-1.5 mt-0.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--mono-green)] animate-pulse-mini" />
            <span>Building</span>
          </div>
        </div>
        <div>
          <div className="font-mono text-[9px] uppercase tracking-widest text-white/40">
            Uptime
          </div>
          <div className="font-mono text-xs text-[var(--mono-blue)] mt-0.5">
            2 yrs · ongoing
          </div>
        </div>
      </div>
    </div>
  );
};
