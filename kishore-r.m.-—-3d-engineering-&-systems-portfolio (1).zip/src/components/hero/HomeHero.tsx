/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Mail, ArrowRight, Dna, Terminal as TerminalIcon } from 'lucide-react';
import { PERSONAL_INFO } from '../../data/portfolioData';
import { BiomedicalScene } from '../3d/BiomedicalScene';
import { HeroTerminal } from './HeroTerminal';

interface HomeHeroProps {
  onNavigate: (page: string) => void;
  onOpenEmailModal: () => void;
}

export const HomeHero: React.FC<HomeHeroProps> = ({
  onNavigate,
  onOpenEmailModal,
}) => {
  const [rightView, setRightView] = useState<'3d' | 'terminal'>('3d');

  return (
    <div className="flex flex-col">
      {/* Hero Section Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-[1fr_460px] min-h-[calc(100vh-3.5rem)] border-b border-[var(--rule)]">
        {/* Left Column: Editorial Profile */}
        <div className="p-8 sm:p-12 lg:p-16 flex flex-col justify-center bg-[var(--surface)]">
          {/* Eyebrow with vital red indicator */}
          <div className="font-mono-code text-[11px] uppercase tracking-widest text-[var(--accent)] mb-5 flex items-center gap-2.5">
            <span className="w-2 h-2 rounded-full bg-[var(--vital)] flex-shrink-0" />
            <span>Biomedical Engineering · Healthcare AI</span>
          </div>

          {/* Heading */}
          <h1 className="font-syne font-extrabold text-5xl sm:text-6xl lg:text-7xl leading-[0.95] tracking-tight text-[var(--ink)] mb-3">
            <span className="block">Kishore</span>
            <span className="block text-[var(--accent)]">R M</span>
            <span className="block italic font-normal text-2xl sm:text-3xl text-[var(--ink3)] mt-3 font-epilogue">
              Student. Builder. Engineer.
            </span>
          </h1>

          {/* Vital ECG Waveform Graphic Bar */}
          <div className="w-full max-w-md h-12 my-6" aria-hidden="true">
            <svg viewBox="0 0 420 46" preserveAspectRatio="none" className="w-full h-full overflow-visible">
              <path className="vital-track" d="M0,23 L420,23" />
              <path
                className="vital-path vital-anim"
                d="M0,23 L70,23 L82,5 L96,41 L108,23 L160,23 L172,12 L184,34 L196,23 L420,23"
              />
            </svg>
          </div>

          {/* Bio text */}
          <p className="text-base text-[var(--ink2)] leading-relaxed max-w-xl mb-8 font-epilogue">
            {PERSONAL_INFO.bio}
          </p>

          {/* Tech and focus tags */}
          <div className="flex flex-wrap gap-2 mb-10">
            <span className="px-3 py-1 bg-[var(--accent-pale)] border border-[var(--accent)]/20 text-[var(--accent)] rounded text-[11px] font-mono-code">
              Healthcare AI
            </span>
            <span className="px-3 py-1 bg-[var(--bg2)] border border-[var(--rule)] text-[var(--ink3)] rounded text-[11px] font-mono-code hover:border-[var(--accent)] transition-colors">
              Medical Imaging
            </span>
            <span className="px-3 py-1 bg-[var(--bg2)] border border-[var(--rule)] text-[var(--ink3)] rounded text-[11px] font-mono-code hover:border-[var(--accent)] transition-colors">
              Python & AIML
            </span>
            <span className="px-3 py-1 bg-[var(--bg2)] border border-[var(--rule)] text-[var(--ink3)] rounded text-[11px] font-mono-code hover:border-[var(--accent)] transition-colors">
              GSSoC '26
            </span>
            <span className="px-3 py-1 bg-[var(--vital-pale)] border border-[var(--vital)]/20 text-[var(--vital)] rounded text-[11px] font-mono-code">
              Biomedical 3D
            </span>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => onNavigate('projects')}
              className="px-5 py-2.5 bg-[var(--accent)] hover:bg-[var(--accent-lt)] text-white rounded text-xs font-mono-code font-medium transition-all shadow-sm flex items-center gap-2"
            >
              <span>View Projects</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => onNavigate('about')}
              className="px-5 py-2.5 border border-[var(--rule)] hover:border-[var(--accent)] hover:text-[var(--accent)] hover:bg-[var(--accent-pale)] rounded text-xs font-mono-code font-medium transition-all"
            >
              About Me
            </button>

            <button
              onClick={onOpenEmailModal}
              className="px-5 py-2.5 bg-[var(--vital-pale)] border border-[var(--vital)]/40 text-[var(--vital)] hover:bg-[var(--vital)] hover:text-white rounded text-xs font-mono-code font-medium transition-all flex items-center gap-2 shadow-sm"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>Send via Email</span>
            </button>
          </div>
        </div>

        {/* Right Column: Switchable 3D Bio-Engine & Terminal */}
        <div className="flex flex-col bg-[var(--mono-bg)] border-t xl:border-t-0 xl:border-l border-[var(--rule)] relative min-h-[480px]">
          {/* Top Switcher Tab Header */}
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-white/10 bg-[var(--mono-bg2)]">
            <span className="font-mono text-[11px] text-white/50">
              EXPLORE VIEWPORT:
            </span>
            <div className="flex items-center gap-1 bg-black/50 p-1 rounded border border-white/10">
              <button
                onClick={() => setRightView('3d')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[10.5px] font-mono transition-all ${
                  rightView === '3d'
                    ? 'bg-[var(--accent)] text-white font-medium shadow-sm'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                <Dna className="w-3 h-3" />
                <span>3D Bio-Engine</span>
              </button>

              <button
                onClick={() => setRightView('terminal')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[10.5px] font-mono transition-all ${
                  rightView === 'terminal'
                    ? 'bg-[var(--accent)] text-white font-medium shadow-sm'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                <TerminalIcon className="w-3 h-3" />
                <span>Live Terminal</span>
              </button>
            </div>
          </div>

          {/* View Content */}
          <div className="flex-1 w-full h-full relative">
            {rightView === '3d' ? (
              <BiomedicalScene />
            ) : (
              <HeroTerminal />
            )}
          </div>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 bg-[var(--rule)] gap-[1px]">
        {PERSONAL_INFO.stats.map((stat, i) => (
          <div
            key={i}
            className={`p-8 bg-[var(--surface)] hover:bg-[var(--bg)] transition-colors relative group reveal-on-scroll delay-${i + 1}`}
          >
            <div className="font-syne font-bold text-3xl sm:text-4xl text-[var(--ink)] mb-2 flex items-baseline gap-1">
              <span>{stat.value.replace('+', '')}</span>
              <sup className="text-xl text-[var(--accent)] font-normal">+</sup>
            </div>
            <div className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--ink3)]">
              {stat.label}
            </div>
            <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-[var(--accent)] to-[var(--vital)] opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        ))}
      </div>
    </div>
  );
};
