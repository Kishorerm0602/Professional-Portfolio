/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Award, CheckCircle2 } from 'lucide-react';
import { EXPERIENCES, CERTIFICATIONS } from '../../data/portfolioData';

export const ExperienceSection: React.FC = () => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] min-h-[calc(100vh-3.5rem)] bg-[var(--rule)] gap-[1px]">
      {/* Main Timeline Column */}
      <div className="p-8 sm:p-12 lg:p-14 bg-[var(--surface)]">
        <div className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--accent)] mb-2 flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[var(--vital)]" />
          <span>// experience</span>
        </div>

        <h2 className="font-syne font-bold text-3xl sm:text-4xl text-[var(--ink)] tracking-tight mb-2">
          Academic & Professional Track
        </h2>
        <p className="font-epilogue italic text-sm text-[var(--ink3)] mb-10">
          Education, clinical hospital trainings, and open-source contributions
        </p>

        {/* Timeline List */}
        <div className="relative pl-7 border-l-2 border-[var(--rule)] space-y-10">
          {EXPERIENCES.map((item, idx) => (
            <div key={item.id} className={`relative group reveal-slide-left delay-${(idx % 4) + 1}`}>
              {/* Timeline Indicator Dot */}
              <div
                className={`absolute -left-[35px] top-1.5 w-3 h-3 rounded-full border-2 transition-all ${
                  item.current
                    ? 'bg-[var(--vital)] border-[var(--vital)] shadow-[0_0_0_4px_rgba(181,64,44,0.2)]'
                    : 'bg-[var(--surface)] border-[var(--accent)] group-hover:scale-125'
                }`}
              />

              {/* Date */}
              <div className="font-mono-code text-[11px] uppercase tracking-wider text-[var(--accent)] font-medium mb-1">
                {item.date}
              </div>

              {/* Role Title */}
              <h3 className="font-syne font-bold text-xl text-[var(--ink)] tracking-tight mb-1">
                {item.role}
              </h3>

              {/* Organization */}
              <div className="text-xs sm:text-[13px] text-[var(--ink3)] mb-3 font-epilogue">
                {item.organization}
              </div>

              {/* Description */}
              <p className="text-xs sm:text-[13.5px] text-[var(--ink2)] leading-relaxed font-epilogue max-w-xl mb-3.5">
                {item.description}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5">
                {item.tags.map((tag, tIdx) => (
                  <span
                    key={tIdx}
                    className="px-2.5 py-0.5 bg-[var(--accent-pale)] border border-[var(--accent)]/15 text-[var(--accent)] rounded text-[9.5px] font-mono-code"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Sidebar: Certifications & Badges */}
      <div className="p-8 sm:p-10 bg-[var(--bg2)] space-y-6">
        <div>
          <div className="font-mono-code text-[10px] uppercase tracking-widest text-[var(--ink3)] pb-2.5 border-b border-[var(--rule)] mb-4 font-semibold flex items-center justify-between">
            <span>Certifications & Badges</span>
            <Award className="w-3.5 h-3.5 text-[var(--accent)]" />
          </div>

          <div className="space-y-4">
            {CERTIFICATIONS.map((cert, cIdx) => (
              <div
                key={cert.id}
                className={`bg-[var(--surface)] border border-[var(--rule)] rounded-md overflow-hidden hover:border-[var(--accent)] transition-all group shadow-sm reveal-slide-right delay-${(cIdx % 4) + 1}`}
              >
                <div className="h-28 overflow-hidden bg-black/5">
                  <img
                    src={cert.image}
                    alt={cert.name}
                    className="w-full h-full object-cover saturate-[0.8] group-hover:saturate-100 group-hover:scale-105 transition-all duration-400"
                  />
                </div>
                <div className="p-3.5">
                  <div className="font-mono-code text-[9.5px] uppercase tracking-widest text-[var(--accent)] mb-1">
                    {cert.issuer}
                  </div>
                  <div className="font-syne font-semibold text-[13px] text-[var(--ink)] mb-1 group-hover:text-[var(--accent)] transition-colors leading-snug">
                    {cert.name}
                  </div>
                  <div className="font-mono-code text-[10px] text-[var(--ink3)] flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-[var(--ok)]" />
                    <span>{cert.date}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
