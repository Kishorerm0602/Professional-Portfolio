/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Dna, Network, Activity, Scan, RotateCw, Eye, Sparkles } from 'lucide-react';

export type BioSceneMode = 'dna' | 'neural' | 'ecg' | 'ct-slice';

interface BiomedicalSceneProps {
  initialMode?: BioSceneMode;
  className?: string;
  compact?: boolean;
}

export const BiomedicalScene: React.FC<BiomedicalSceneProps> = ({
  initialMode = 'dna',
  className = '',
  compact = false,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [mode, setMode] = useState<BioSceneMode>(initialMode);
  const [wireframe, setWireframe] = useState<boolean>(false);
  const [autoRotate, setAutoRotate] = useState<boolean>(true);
  const [rotationSpeed, setRotationSpeed] = useState<number>(1);
  const [activeTelemetry, setActiveTelemetry] = useState({
    fps: '60',
    bpm: '72',
    nodes: '64',
    modeLabel: 'DNA Double Helix',
  });

  // Mutable state reference for render loop
  const stateRef = useRef({
    mode,
    wireframe,
    autoRotate,
    rotationSpeed,
    mouse: { x: 0, y: 0 },
    targetRotation: { x: 0.15, y: 0.4 },
    currentRotation: { x: 0.15, y: 0.4 },
    isDragging: false,
    prevPointer: { x: 0, y: 0 },
    clock: new THREE.Clock(),
  });

  // Keep stateRef in sync with React state
  useEffect(() => {
    stateRef.current.mode = mode;
    stateRef.current.wireframe = wireframe;
    stateRef.current.autoRotate = autoRotate;
    stateRef.current.rotationSpeed = rotationSpeed;

    const labels: Record<BioSceneMode, string> = {
      dna: 'DNA Double Helix',
      neural: 'Healthcare AI Net',
      ecg: 'ECG Biosensor Wave',
      'ct-slice': 'CT/MRI Slice Stack',
    };
    setActiveTelemetry((prev) => ({
      ...prev,
      modeLabel: labels[mode],
      nodes: mode === 'dna' ? '48 Base Pairs' : mode === 'neural' ? '96 Synaptic Nodes' : mode === 'ecg' ? '72 BPM' : '16 Slices',
    }));
  }, [mode, wireframe, autoRotate, rotationSpeed]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Detect software WebGL guard
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Setup Three.js Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x101317, 0.035);

    const width = container.clientWidth || 400;
    const height = container.clientHeight || 400;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, 8.5);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 3. Environment Map (PMREM Studio Reflection)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 4. Lighting Rig
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xe8f0ff, 2.2);
    keyLight.position.set(5, 7, 6);
    scene.add(keyLight);

    const vitalRimLight = new THREE.PointLight(0xb5402c, 3.5, 15);
    vitalRimLight.position.set(-5, -3, 3);
    scene.add(vitalRimLight);

    const steelFillLight = new THREE.PointLight(0x3e84b5, 2.8, 15);
    steelFillLight.position.set(4, -4, -3);
    scene.add(steelFillLight);

    // Master Group for All Models
    const masterGroup = new THREE.Group();
    scene.add(masterGroup);

    // Reusable Materials
    const steelMat = new THREE.MeshPhysicalMaterial({
      color: 0x1f5a82,
      metalness: 0.85,
      roughness: 0.2,
      clearcoat: 0.8,
      clearcoatRoughness: 0.1,
    });

    const vitalMat = new THREE.MeshPhysicalMaterial({
      color: 0xb5402c,
      emissive: 0x5a1810,
      emissiveIntensity: 0.5,
      metalness: 0.4,
      roughness: 0.25,
      clearcoat: 0.9,
    });

    const greenMat = new THREE.MeshPhysicalMaterial({
      color: 0x3e7d54,
      emissive: 0x10301a,
      emissiveIntensity: 0.4,
      metalness: 0.5,
      roughness: 0.3,
    });

    const goldMat = new THREE.MeshPhysicalMaterial({
      color: 0xe0a878,
      emissive: 0x402810,
      emissiveIntensity: 0.3,
      metalness: 0.75,
      roughness: 0.2,
    });

    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.45,
      roughness: 0.1,
      metalness: 0.1,
      transmission: isSoftwareGl ? 0 : 0.85,
      ior: 1.45,
    });

    // ─────────────────────────────────────────────────────────
    // MODEL 1: PROCEDURAL 3D DNA DOUBLE HELIX
    // ─────────────────────────────────────────────────────────
    const dnaGroup = new THREE.Group();
    const dnaStrandCount = 28;
    const helixRadius = 1.35;
    const helixHeight = 5.6;
    const sphereGeo = new THREE.SphereGeometry(0.14, 16, 16);
    const cylinderGeo = new THREE.CylinderGeometry(0.04, 0.04, 1, 12);
    const rungMeshArr: { mesh: THREE.Mesh; initialY: number; index: number }[] = [];

    for (let i = 0; i < dnaStrandCount; i++) {
      const t = (i / dnaStrandCount) * Math.PI * 4;
      const y = (i / dnaStrandCount) * helixHeight - helixHeight / 2;

      // Backbone 1
      const x1 = Math.cos(t) * helixRadius;
      const z1 = Math.sin(t) * helixRadius;
      const s1 = new THREE.Mesh(sphereGeo, i % 2 === 0 ? steelMat : vitalMat);
      s1.position.set(x1, y, z1);
      dnaGroup.add(s1);

      // Backbone 2
      const x2 = Math.cos(t + Math.PI) * helixRadius;
      const z2 = Math.sin(t + Math.PI) * helixRadius;
      const s2 = new THREE.Mesh(sphereGeo, i % 2 === 0 ? goldMat : greenMat);
      s2.position.set(x2, y, z2);
      dnaGroup.add(s2);

      // Connecting Base-Pair Rung
      const rungMat = i % 4 === 0 ? vitalMat : i % 4 === 1 ? steelMat : i % 4 === 2 ? greenMat : goldMat;
      const rung = new THREE.Mesh(cylinderGeo, rungMat);
      rung.position.set((x1 + x2) / 2, y, (z1 + z2) / 2);

      const dir = new THREE.Vector3(x2 - x1, 0, z2 - z1);
      rung.scale.set(1, dir.length(), 1);
      rung.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());

      dnaGroup.add(rung);
      rungMeshArr.push({ mesh: rung, initialY: y, index: i });
    }

    // Molecular dust cloud particles
    const particleCount = 70;
    const particleGeo = new THREE.BufferGeometry();
    const particlePos = new Float32Array(particleCount * 3);
    for (let p = 0; p < particleCount * 3; p += 3) {
      particlePos[p] = (Math.random() - 0.5) * 6;
      particlePos[p + 1] = (Math.random() - 0.5) * 6;
      particlePos[p + 2] = (Math.random() - 0.5) * 6;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePos, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x3e84b5,
      size: 0.08,
      transparent: true,
      opacity: 0.6,
    });
    const dustPoints = new THREE.Points(particleGeo, particleMat);
    dnaGroup.add(dustPoints);

    masterGroup.add(dnaGroup);

    // ─────────────────────────────────────────────────────────
    // MODEL 2: PROCEDURAL HEALTHCARE AI NEURAL NETWORK
    // ─────────────────────────────────────────────────────────
    const neuralGroup = new THREE.Group();
    const layerDefs = [6, 10, 14, 10, 5];
    const layerSpacing = 1.1;
    const neuralNodes: { mesh: THREE.Mesh; pos: THREE.Vector3; layer: number }[] = [];

    layerDefs.forEach((count, lIdx) => {
      const lx = (lIdx - (layerDefs.length - 1) / 2) * layerSpacing;
      for (let n = 0; n < count; n++) {
        const radius = 1.4 * Math.sin(((lIdx + 0.5) / layerDefs.length) * Math.PI);
        const theta = (n / count) * Math.PI * 2;
        const ly = Math.sin(theta) * radius + (Math.random() - 0.5) * 0.2;
        const lz = Math.cos(theta) * radius + (Math.random() - 0.5) * 0.2;

        const isOutput = lIdx === layerDefs.length - 1;
        const isInput = lIdx === 0;
        const nMat = isOutput ? vitalMat : isInput ? steelMat : lIdx % 2 === 0 ? greenMat : goldMat;

        const nodeMesh = new THREE.Mesh(new THREE.SphereGeometry(0.12, 14, 14), nMat);
        nodeMesh.position.set(lx, ly, lz);
        neuralGroup.add(nodeMesh);
        neuralNodes.push({ mesh: nodeMesh, pos: new THREE.Vector3(lx, ly, lz), layer: lIdx });
      }
    });

    // Connecting Synaptic Axons
    const axonLines: THREE.Line[] = [];
    const lineMat = new THREE.LineBasicMaterial({
      color: 0x3e84b5,
      transparent: true,
      opacity: 0.25,
    });
    const activeLineMat = new THREE.LineBasicMaterial({
      color: 0xb5402c,
      transparent: true,
      opacity: 0.7,
    });

    for (let i = 0; i < neuralNodes.length; i++) {
      for (let j = i + 1; j < neuralNodes.length; j++) {
        if (neuralNodes[j].layer === neuralNodes[i].layer + 1) {
          const dist = neuralNodes[i].pos.distanceTo(neuralNodes[j].pos);
          if (dist < 1.7) {
            const lineGeo = new THREE.BufferGeometry().setFromPoints([
              neuralNodes[i].pos,
              neuralNodes[j].pos,
            ]);
            const line = new THREE.Line(lineGeo, Math.random() > 0.75 ? activeLineMat : lineMat);
            neuralGroup.add(line);
            axonLines.push(line);
          }
        }
      }
    }
    neuralGroup.visible = false;
    masterGroup.add(neuralGroup);

    // ─────────────────────────────────────────────────────────
    // MODEL 3: PROCEDURAL 3D ECG BIOSENSOR & CARDIAC MESH
    // ─────────────────────────────────────────────────────────
    const ecgGroup = new THREE.Group();

    // 1. Central pulsing cardioid torus / anatomical orb
    const heartGeo = new THREE.TorusKnotGeometry(1.05, 0.32, 64, 16, 2, 3);
    const heartMesh = new THREE.Mesh(heartGeo, vitalMat);
    ecgGroup.add(heartMesh);

    // 2. Encircling 3D ECG spatial trace wave
    const wavePoints: THREE.Vector3[] = [];
    const waveLength = 180;
    for (let w = 0; w < waveLength; w++) {
      const angle = (w / waveLength) * Math.PI * 2;
      const r = 2.1;
      let spike = 0;
      const seg = w % 45;
      if (seg === 15) spike = 0.2; // P wave
      if (seg === 20) spike = -0.3; // Q
      if (seg === 23) spike = 1.35; // R peak
      if (seg === 26) spike = -0.45; // S
      if (seg === 33) spike = 0.35; // T wave

      const wx = Math.cos(angle) * r;
      const wz = Math.sin(angle) * r;
      const wy = spike * 0.75;
      wavePoints.push(new THREE.Vector3(wx, wy, wz));
    }
    wavePoints.push(wavePoints[0]); // close loop
    const waveGeo = new THREE.BufferGeometry().setFromPoints(wavePoints);
    const ecgLine = new THREE.Line(
      waveGeo,
      new THREE.LineBasicMaterial({ color: 0xb5402c, linewidth: 2 })
    );
    ecgGroup.add(ecgLine);

    // Outer orbital rings (biomedical sensor telemetry coordinate frames)
    const ringGeo = new THREE.RingGeometry(2.35, 2.38, 48);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x1f5a82,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.4,
    });
    const ringMesh1 = new THREE.Mesh(ringGeo, ringMat);
    ringMesh1.rotation.x = Math.PI / 2;
    ecgGroup.add(ringMesh1);

    const ringMesh2 = new THREE.Mesh(ringGeo, ringMat);
    ringMesh2.rotation.y = Math.PI / 3;
    ecgGroup.add(ringMesh2);

    ecgGroup.visible = false;
    masterGroup.add(ecgGroup);

    // ─────────────────────────────────────────────────────────
    // MODEL 4: 3D MEDICAL IMAGING CT/MRI SLICE STACK
    // ─────────────────────────────────────────────────────────
    const ctGroup = new THREE.Group();
    const sliceCount = 9;
    const sliceWidth = 2.4;
    const sliceSpacing = 0.38;
    const slicePlanes: THREE.Mesh[] = [];

    // Create a procedural procedural medical slice canvas texture
    const createSliceCanvas = (sliceIdx: number) => {
      const c = document.createElement('canvas');
      c.width = 128;
      c.height = 128;
      const ctx = c.getContext('2d')!;
      ctx.fillStyle = '#0f141a';
      ctx.fillRect(0, 0, 128, 128);

      // Draw simulated cortical brain/tissue contour
      const grad = ctx.createRadialGradient(64, 64, 10, 64, 64, 52);
      grad.addColorStop(0, '#5b9bcf');
      grad.addColorStop(0.5, '#1f5a82');
      grad.addColorStop(0.8, '#122536');
      grad.addColorStop(1, 'transparent');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.ellipse(64, 64, 45, 52 + Math.sin(sliceIdx) * 6, 0, 0, Math.PI * 2);
      ctx.fill();

      // Ventricles & tissue contours
      ctx.strokeStyle = '#b5402c';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(52, 60, 10 + sliceIdx, 0, Math.PI);
      ctx.arc(76, 60, 10 + sliceIdx, 0, Math.PI);
      ctx.stroke();

      // Matrix scan line
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.font = '8px monospace';
      ctx.fillText(`AX_${sliceIdx + 1} / 512`, 8, 18);
      ctx.fillText(`HU: +${35 + sliceIdx * 8}`, 8, 118);

      const tex = new THREE.CanvasTexture(c);
      tex.colorSpace = THREE.SRGBColorSpace;
      return tex;
    };

    for (let s = 0; s < sliceCount; s++) {
      const zOffset = (s - (sliceCount - 1) / 2) * sliceSpacing;
      const planeGeo = new THREE.PlaneGeometry(sliceWidth, sliceWidth);
      const sliceTexture = createSliceCanvas(s);
      const pMat = new THREE.MeshBasicMaterial({
        map: sliceTexture,
        transparent: true,
        opacity: 0.85,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const slicePlane = new THREE.Mesh(planeGeo, pMat);
      slicePlane.position.set(0, 0, zOffset);
      ctGroup.add(slicePlane);
      slicePlanes.push(slicePlane);
    }

    // Laser scanner line
    const laserGeo = new THREE.BoxGeometry(sliceWidth * 1.1, 0.04, 0.04);
    const laserMat = new THREE.MeshBasicMaterial({ color: 0xb5402c });
    const laserMesh = new THREE.Mesh(laserGeo, laserMat);
    laserMesh.position.set(0, 0, 0);
    ctGroup.add(laserMesh);

    ctGroup.visible = false;
    masterGroup.add(ctGroup);

    // ─────────────────────────────────────────────────────────
    // POINTER & TOUCH ROTATION
    // ─────────────────────────────────────────────────────────
    const handlePointerDown = (e: MouseEvent | TouchEvent) => {
      stateRef.current.isDragging = true;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      stateRef.current.prevPointer = { x: clientX, y: clientY };
    };

    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      if (!stateRef.current.isDragging) return;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

      const deltaX = clientX - stateRef.current.prevPointer.x;
      const deltaY = clientY - stateRef.current.prevPointer.y;

      stateRef.current.targetRotation.y += deltaX * 0.008;
      stateRef.current.targetRotation.x += deltaY * 0.008;

      // Clamp vertical tilt
      stateRef.current.targetRotation.x = Math.max(-1.1, Math.min(1.1, stateRef.current.targetRotation.x));

      stateRef.current.prevPointer = { x: clientX, y: clientY };
    };

    const handlePointerUp = () => {
      stateRef.current.isDragging = false;
    };

    const domEl = renderer.domElement;
    domEl.addEventListener('mousedown', handlePointerDown);
    window.addEventListener('mousemove', handlePointerMove);
    window.addEventListener('mouseup', handlePointerUp);
    domEl.addEventListener('touchstart', handlePointerDown, { passive: true });
    window.addEventListener('touchmove', handlePointerMove, { passive: true });
    window.addEventListener('touchend', handlePointerUp);

    // ─────────────────────────────────────────────────────────
    // ANIMATION TICK LOOP
    // ─────────────────────────────────────────────────────────
    let frameId = 0;
    let laserY = -1;
    let laserDir = 1;

    const animate = () => {
      const delta = stateRef.current.clock.getDelta();
      const elapsed = stateRef.current.clock.getElapsedTime();

      // Smooth exponential damping rotation
      stateRef.current.currentRotation.x = THREE.MathUtils.damp(
        stateRef.current.currentRotation.x,
        stateRef.current.targetRotation.x,
        8,
        delta
      );
      stateRef.current.currentRotation.y = THREE.MathUtils.damp(
        stateRef.current.currentRotation.y,
        stateRef.current.targetRotation.y,
        8,
        delta
      );

      // Auto rotation
      if (stateRef.current.autoRotate && !stateRef.current.isDragging) {
        stateRef.current.targetRotation.y += 0.45 * stateRef.current.rotationSpeed * delta;
      }

      masterGroup.rotation.x = stateRef.current.currentRotation.x;
      masterGroup.rotation.y = stateRef.current.currentRotation.y;

      // Mode-specific animations
      const curMode = stateRef.current.mode;
      dnaGroup.visible = curMode === 'dna';
      neuralGroup.visible = curMode === 'neural';
      ecgGroup.visible = curMode === 'ecg';
      ctGroup.visible = curMode === 'ct-slice';

      // Update wireframe state
      const isWire = stateRef.current.wireframe;
      steelMat.wireframe = isWire;
      vitalMat.wireframe = isWire;
      greenMat.wireframe = isWire;
      goldMat.wireframe = isWire;

      if (curMode === 'dna') {
        // Floating pulse on rungs
        rungMeshArr.forEach((item) => {
          const wave = Math.sin(elapsed * 2.5 + item.index * 0.2);
          item.mesh.scale.x = 1 + wave * 0.15;
          item.mesh.scale.z = 1 + wave * 0.15;
        });
        dustPoints.rotation.y = elapsed * 0.1;
      } else if (curMode === 'neural') {
        // Pulse neural node scales
        neuralNodes.forEach((node, idx) => {
          const pulse = Math.sin(elapsed * 3 + idx * 0.3) * 0.15 + 1;
          node.mesh.scale.setScalar(pulse);
        });
      } else if (curMode === 'ecg') {
        // Heartbeat systolic/diastolic pulse
        const beatCycle = (elapsed * 1.2) % 1;
        let heartScale = 1;
        if (beatCycle < 0.15) {
          heartScale = 1 + Math.sin((beatCycle / 0.15) * Math.PI) * 0.22;
        } else if (beatCycle < 0.35) {
          heartScale = 1 + Math.sin(((beatCycle - 0.15) / 0.2) * Math.PI) * 0.12;
        }
        heartMesh.scale.setScalar(heartScale);
        ringMesh1.rotation.z = elapsed * 0.3;
        ringMesh2.rotation.x = elapsed * 0.25;
      } else if (curMode === 'ct-slice') {
        // Scanner plane sweeps vertically
        laserY += laserDir * delta * 1.4;
        if (laserY > 1.2) laserDir = -1;
        if (laserY < -1.2) laserDir = 1;
        laserMesh.position.y = laserY;

        slicePlanes.forEach((plane, idx) => {
          const distToLaser = Math.abs(plane.position.y - laserY);
          const mat = plane.material as THREE.MeshBasicMaterial;
          mat.opacity = 0.5 + Math.sin(elapsed * 2 + idx) * 0.15 + (distToLaser < 0.2 ? 0.35 : 0);
        });
      }

      renderer.render(scene, camera);
      frameId = requestAnimationFrame(animate);
    };

    frameId = requestAnimationFrame(animate);

    // ─────────────────────────────────────────────────────────
    // RESIZE OBSERVER
    // ─────────────────────────────────────────────────────────
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (w === 0 || h === 0) return;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);

    // Clean up
    return () => {
      cancelAnimationFrame(frameId);
      resizeObserver.disconnect();
      domEl.removeEventListener('mousedown', handlePointerDown);
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
      domEl.removeEventListener('touchstart', handlePointerDown);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('touchend', handlePointerUp);
      renderer.dispose();
      pmremGenerator.dispose();
    };
  }, []);

  return (
    <div className={`relative flex flex-col w-full h-full select-none bg-[var(--mono-bg)] text-[var(--mono-text)] border border-[var(--rule)] rounded-md overflow-hidden ${className}`}>
      {/* Top Header / Mode Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 border-b border-white/10 bg-[var(--mono-bg2)] text-xs z-10">
        <div className="flex items-center gap-1.5 font-mono text-[11px] text-white/80">
          <span className="w-2 h-2 rounded-full bg-[var(--vital)]"></span>
          <span className="font-semibold text-white">3D Bio-Engine</span>
          <span className="text-white/40">/</span>
          <span className="text-[var(--mono-green)]">{activeTelemetry.modeLabel}</span>
        </div>

        {/* Mode Selector Buttons */}
        <div className="flex items-center gap-1 bg-black/40 p-0.5 rounded border border-white/10">
          <button
            onClick={() => setMode('dna')}
            title="3D DNA Double Helix"
            className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-mono transition-all ${
              mode === 'dna'
                ? 'bg-[var(--accent)] text-white font-medium shadow-sm'
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <Dna className="w-3 h-3" />
            <span className="hidden sm:inline">DNA Helix</span>
          </button>

          <button
            onClick={() => setMode('neural')}
            title="3D Healthcare AI Neural Synapse"
            className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-mono transition-all ${
              mode === 'neural'
                ? 'bg-[var(--accent)] text-white font-medium shadow-sm'
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <Network className="w-3 h-3" />
            <span className="hidden sm:inline">Neural AI</span>
          </button>

          <button
            onClick={() => setMode('ecg')}
            title="3D ECG Pulse Waveform"
            className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-mono transition-all ${
              mode === 'ecg'
                ? 'bg-[var(--accent)] text-white font-medium shadow-sm'
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <Activity className="w-3 h-3" />
            <span className="hidden sm:inline">ECG Pulse</span>
          </button>

          <button
            onClick={() => setMode('ct-slice')}
            title="3D CT/MRI Multi-Planar Slices"
            className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-mono transition-all ${
              mode === 'ct-slice'
                ? 'bg-[var(--accent)] text-white font-medium shadow-sm'
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <Scan className="w-3 h-3" />
            <span className="hidden sm:inline">CT Slices</span>
          </button>
        </div>
      </div>

      {/* Main 3D Canvas Mounting Area */}
      <div className="relative flex-1 w-full min-h-[320px] cursor-grab active:cursor-grabbing">
        <div ref={mountRef} className="absolute inset-0 w-full h-full" />

        {/* Spatial Coordinate Overlay Badges */}
        <div className="absolute top-3 left-3 pointer-events-none font-mono text-[9px] text-white/40 space-y-0.5">
          <div>BIO_SYS: CHENNAI_BME_LAB</div>
          <div>SHADER: PBR_STUDIO_R160+</div>
        </div>

        <div className="absolute top-3 right-3 pointer-events-none font-mono text-[9px] text-right space-y-0.5">
          <div className="text-[var(--mono-green)] flex items-center justify-end gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--mono-green)]"></span>
            LIVE VITAL SIGNAL
          </div>
          <div className="text-white/40">{activeTelemetry.nodes}</div>
        </div>

        {/* Drag Hint */}
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 pointer-events-none font-mono text-[10px] text-white/30 bg-black/40 px-2 py-0.5 rounded backdrop-blur-sm border border-white/5">
          Drag to rotate 3D view · Orbit active
        </div>

        {/* Compact Bottom Controls Bar */}
        <div className="absolute bottom-2 inset-x-2 flex items-center justify-between gap-2 px-3 py-1.5 bg-black/60 backdrop-blur-md rounded border border-white/10 text-[10px] font-mono z-10">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setAutoRotate(!autoRotate)}
              className={`flex items-center gap-1 px-2 py-0.5 rounded border transition-colors ${
                autoRotate
                  ? 'border-[var(--accent)] text-[var(--accent-lt)] bg-[var(--accent)]/10'
                  : 'border-white/20 text-white/50 hover:text-white'
              }`}
            >
              <RotateCw className="w-2.5 h-2.5" />
              <span>{autoRotate ? 'Auto: On' : 'Auto: Off'}</span>
            </button>

            <button
              onClick={() => setWireframe(!wireframe)}
              className={`flex items-center gap-1 px-2 py-0.5 rounded border transition-colors ${
                wireframe
                  ? 'border-[var(--vital)] text-[var(--vital-lt)] bg-[var(--vital)]/10'
                  : 'border-white/20 text-white/50 hover:text-white'
              }`}
            >
              <Eye className="w-2.5 h-2.5" />
              <span>{wireframe ? 'Mesh' : 'PBR'}</span>
            </button>
          </div>

          <div className="flex items-center gap-3 text-white/60">
            <div className="flex items-center gap-1">
              <span className="text-white/40">FREQ:</span>
              <button
                onClick={() => setRotationSpeed((s) => (s >= 2 ? 0.5 : s + 0.5))}
                className="hover:text-white text-white/80 underline decoration-dotted"
              >
                {rotationSpeed}x
              </button>
            </div>
            <div className="hidden sm:flex items-center gap-1 text-[var(--mono-blue)]">
              <Sparkles className="w-2.5 h-2.5" />
              <span>WEBGL 2.0</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
